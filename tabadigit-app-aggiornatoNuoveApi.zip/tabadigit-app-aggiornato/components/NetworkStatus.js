/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { faWifi, faWifiSlash } from "@fortawesome/free-solid-svg-icons";
import { colore } from "../colore";

/**
 * Componente per visualizzare lo stato della connessione al router
 * Verde quando online, rosso quando offline
 * 
 * @author Mandalà Giuseppe
 */
const NetworkStatus = () => {
  const [isConnected, setIsConnected] = useState(true);

  // Funzione per verificare la connessione al server
  const checkServerConnection = async () => {
    try {
      // Timeout dopo 5 secondi
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      
      const response = await fetch(require('../constants').SERVER_IP, {
        method: 'HEAD',
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      setIsConnected(response.ok);
    } catch (error) {
      console.error('Errore di connessione:', error);
      setIsConnected(false);
    }
  };

  // Verifica la connessione ogni 10 secondi
  useEffect(() => {
    // Verifica iniziale
    checkServerConnection();
    
    // Imposta un intervallo per verificare periodicamente
    const intervalId = setInterval(() => {
      checkServerConnection();
    }, 10000);
    
    // Pulizia dell'intervallo quando il componente viene smontato
    return () => clearInterval(intervalId);
  }, []);

  return (
    <View style={styles.container}>
      <FontAwesomeIcon 
        icon={isConnected ? faWifi : faWifiSlash} 
        size={20} 
        color={isConnected ? '#4CAF50' : '#F44336'} 
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 5,
    justifyContent: 'center',
    alignItems: 'center',
  }
});

export default NetworkStatus;
