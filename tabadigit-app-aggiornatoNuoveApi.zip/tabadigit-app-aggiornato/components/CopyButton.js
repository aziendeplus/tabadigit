import React from "react";
import { TouchableHighlight } from "react-native";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { faCopy } from "@fortawesome/free-solid-svg-icons";
import { useNavigation } from "@react-navigation/native";
import { colore } from "../colore";

const CopyButton = ({ product }) => {
  const navigation = useNavigation();
  return (
    <TouchableHighlight
      onPress={() => navigation.navigate("DuplicaProdotto", { data: product })}
      style={{ marginRight: 20 }}
    >
      <FontAwesomeIcon icon={faCopy} size={25} color={colore} />
    </TouchableHighlight>
  );
};

export default CopyButton;
