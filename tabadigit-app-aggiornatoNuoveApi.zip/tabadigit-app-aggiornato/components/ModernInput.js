/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

import React from 'react';
import { StyleSheet, View, Text, TextInput as RNTextInput } from 'react-native';
import { theme, commonStyles } from '../theme';

/**
 * Componente ModernInput - Campo di input moderno con stile migliorato
 * Sostituisce InputCode con un componente più moderno e coerente con il design system
 * 
 * @author Mandalà Giuseppe
 */
const ModernInput = ({ 
  label, 
  value, 
  setValue, 
  placeholder = '', 
  keyboardType = 'default',
  secureTextEntry = false,
  error = null,
  maxLength,
  autoFocus = false,
  style = {},
  inputRef = null
}) => {
  return (
    <View style={[styles.container, style]}>
      {label && <Text style={styles.label}>{label}</Text>}
      
      <RNTextInput
        style={[
          styles.input,
          error && styles.inputError
        ]}
        value={value}
        onChangeText={setValue}
        placeholder={placeholder}
        keyboardType={keyboardType}
        secureTextEntry={secureTextEntry}
        maxLength={maxLength}
        autoFocus={autoFocus}
        ref={inputRef}
        placeholderTextColor={theme.colors.placeholder}
      />
      
      {error && <Text style={styles.errorText}>{error}</Text>}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    marginBottom: theme.spacing.md,
  },
  label: {
    fontSize: theme.typography.fontSize.md,
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
    fontWeight: '500',
  },
  input: {
    ...commonStyles.input,
    height: 50,
    width: '100%',
  },
  inputError: {
    borderColor: theme.colors.error,
  },
  errorText: {
    color: theme.colors.error,
    fontSize: theme.typography.fontSize.sm,
    marginTop: theme.spacing.xs,
  }
});

export default ModernInput;
