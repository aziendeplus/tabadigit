/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, TextInput } from 'react-native';
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { faLightbulb, faTimes } from "@fortawesome/free-solid-svg-icons";
import { colore } from "../colore";
import { controlEslLed } from "../api";
import { useSelector } from "react-redux";

/**
 * Componente per gestire il flash del LED sulle etichette ESL
 * 
 * @author Mandalà Giuseppe
 */
const LedFlashControl = ({ eslBarcode, visible, onClose }) => {
  const [flashDuration, setFlashDuration] = useState('5');
  const [isFlashing, setIsFlashing] = useState(false);
  const { token, selectedStore } = useSelector((rootState) => rootState.auth);
  const [errorMessage, setErrorMessage] = useState('');

  const handleFlash = async () => {
    if (!eslBarcode) {
      setErrorMessage('Codice ESL non valido');
      return;
    }

    setIsFlashing(true);
    setErrorMessage('');

    try {
      // Durata in secondi, convertita da stringa a numero
      const duration = parseInt(flashDuration, 10) || 5;
      
      // Chiamata all'API per controllare il LED
      const response = await controlEslLed(token, selectedStore, eslBarcode, 'flash');
      
      if (response.success) {
        // Simuliamo la durata del flash
        setTimeout(() => {
          setIsFlashing(false);
        }, duration * 1000);
      } else {
        setErrorMessage(response.message || 'Errore durante l\'attivazione del flash');
        setIsFlashing(false);
      }
    } catch (error) {
      console.error('Errore durante il controllo del LED:', error);
      setErrorMessage('Si è verificato un errore durante l\'attivazione del flash');
      setIsFlashing(false);
    }
  };

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={visible}
      onRequestClose={onClose}
    >
      <View style={styles.centeredView}>
        <View style={styles.modalView}>
          <View style={styles.header}>
            <Text style={styles.modalTitle}>Controllo Flash LED</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <FontAwesomeIcon icon={faTimes} size={20} color="#666" />
            </TouchableOpacity>
          </View>
          
          <Text style={styles.eslCode}>ESL: {eslBarcode}</Text>
          
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Durata Flash (secondi):</Text>
            <TextInput
              style={styles.input}
              value={flashDuration}
              onChangeText={setFlashDuration}
              keyboardType="numeric"
              maxLength={2}
              editable={!isFlashing}
            />
          </View>
          
          {errorMessage ? (
            <Text style={styles.errorText}>{errorMessage}</Text>
          ) : null}
          
          <TouchableOpacity
            style={[
              styles.flashButton,
              isFlashing ? styles.flashingButton : null,
              isFlashing ? { opacity: 0.7 } : null
            ]}
            onPress={handleFlash}
            disabled={isFlashing}
          >
            <FontAwesomeIcon 
              icon={faLightbulb} 
              size={24} 
              color="white" 
              style={styles.buttonIcon} 
            />
            <Text style={styles.flashButtonText}>
              {isFlashing ? 'LED Lampeggiante...' : 'Attiva Flash LED'}
            </Text>
          </TouchableOpacity>
          
          <Text style={styles.infoText}>
            Questa funzione fa lampeggiare il LED dell'etichetta elettronica per facilitarne l'identificazione.
          </Text>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalView: {
    width: '85%',
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colore,
  },
  closeButton: {
    padding: 5,
  },
  eslCode: {
    fontSize: 16,
    marginBottom: 20,
    fontWeight: '500',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    marginRight: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    padding: 8,
    width: 60,
    textAlign: 'center',
    fontSize: 16,
  },
  flashButton: {
    backgroundColor: colore,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
  },
  flashingButton: {
    backgroundColor: '#FFA500',
  },
  buttonIcon: {
    marginRight: 10,
  },
  flashButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  errorText: {
    color: 'red',
    marginBottom: 15,
    textAlign: 'center',
  },
  infoText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    fontStyle: 'italic',
  },
});

export default LedFlashControl;
