import React, { useEffect, useState } from "react";
import { StyleSheet, View, TouchableOpacity } from "react-native";
import { TextInput } from "react-native-paper";
import { colore } from "../colore";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { faCamera, faCheck, faTimes } from "@fortawesome/free-solid-svg-icons";
import { useNavigation, useRoute } from "@react-navigation/native";
import NfcManager, { NfcEvents, Ndef } from "react-native-nfc-manager";
import AwesomeAlert from "react-native-awesome-alerts";
import { useSelector } from "react-redux";

const InputCode = React.forwardRef(
  ({ id, value, setValue, label, withNFC = true }, ref) => {
    const { storesInfo } = useSelector((rootState) => rootState.auth);
    const [alert, setAlert] = useState(false);
    const navigation = useNavigation();
    const route = useRoute();

    useEffect(() => {
      if (route?.params?.qrCodeId === id && value !== route.params.data) {
        console.log("Data qrcode", value, route.params.data);
        setValue(route.params.data);
      }
    }, [route?.params?.qrCodeId, route?.params?.data]);

    useEffect(() => {
      const cleanUp = () => {
        NfcManager.setEventListener(NfcEvents.DiscoverTag, null);
      };

      const activateNFC = async () => {
        try {
          await NfcManager.start();

          NfcManager.setEventListener(NfcEvents.DiscoverTag, (tag) => {
            const nfcCode = Ndef.text.decodePayload(tag.ndefMessage[0].payload);

            let row;

            for (const stores of Object.values(storesInfo)) {
              row = stores.data.find(
                (row) => row[0].toUpperCase() === nfcCode.toUpperCase()
              );
              if (row) break;
            }

            if (row) {
              setValue(row[1]);
            } else {
              setAlert(true);
            }
          });

          NfcManager.registerTagEvent();
        } catch (err) {
          console.error(err);
        }
      };

      if (withNFC) {
        activateNFC();
        return cleanUp;
      }
    }, [withNFC, storesInfo]);

    return (
      <View style={styles.block}>
        <View
          style={{ flexDirection: "row", alignItems: "center", width: "95%" }}
        >
          <TextInput
            ref={ref}
            label={label}
            theme={{ colors: { primary: colore } }}
            value={value}
            onChangeText={setValue}
            style={styles.textInput}
            placeholder="Inserisci/Scannerizza"
            editable={true}
          />
          <View style={styles.iconContainer}>
            <TouchableOpacity
              onPress={() => {
                navigation.navigate("QRpage", {
                  qrCodeId: id,
                  returnToPage: route.name,
                });
              }}
            >
              <FontAwesomeIcon icon={faCamera} size={26} />
            </TouchableOpacity>
            {value ? (
              <FontAwesomeIcon
                style={{ marginLeft: 10 }}
                icon={faCheck}
                size={26}
                color={colore}
              />
            ) : (
              <FontAwesomeIcon
                style={{ marginLeft: 10 }}
                icon={faTimes}
                size={26}
                color="red"
              />
            )}
          </View>
        </View>

        <AwesomeAlert
          overlayStyle={{ height: "100%" }}
          show={alert}
          title={"Errore"}
          message={"Codice NFC non identificato. Negozio sbagliato?"}
          closeOnTouchOutside={true}
          closeOnHardwareBackPress={false}
          showConfirmButton={true}
          confirmText="OK"
          confirmButtonColor={colore}
          onConfirmPressed={() => setAlert(false)}
          onDismiss={() => setAlert(false)}
        />
      </View>
    );
  }
);

const styles = StyleSheet.create({
  block: {
    flexDirection: "row",
    width: "100%",
    alignItems: "center",
    height: 55,
    justifyContent: "center",
  },
  iconContainer: {
    flexDirection: "row",
    width: "10%",
    alignItems: "center",
    height: "100%",
    marginHorizontal: 3,
  },
  textInput: {
    width: "80%",
    height: 55,
    backgroundColor: "white",
    fontSize: 18,
  },
});

export default InputCode;
