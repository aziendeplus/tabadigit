import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import React from 'react'
import { faTrashAlt } from '@fortawesome/free-solid-svg-icons'
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native'

const Cig = ({ item, onDelete, navigation}) => {

    const navigate = () => {
        navigation.navigate("ProductDetails", { item });
    }


    return (
        <TouchableOpacity style={styles.container} onPress={navigate} >
            <View style = {styles.infoContainer}>
                <Text style={styles.title}>{item.itemTitle}</Text>
                <Text>Quantità: {item.amount}</Text>
                <Text>Totale: {item.amount * item.price} €</Text>
            </View>
            <View style={styles.actions}>
                <TouchableOpacity
                    onPress={onDelete}
                >
                    <FontAwesomeIcon icon={faTrashAlt} size={20} />
                </TouchableOpacity>
            </View>
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    container: {
        height: 120,
        width:'90%',
        flexDirection: 'row',
        alignItems: "center",
        marginVertical:11,
        borderRadius: 10,
        backgroundColor: "white",
        padding: 20,
        justifyContent: "space-between",
        
    },  
    title: {
        fontWeight: "bold",
        fontSize: 18,
        maxWidth:'90%'
    },
    actions: {
        width: 30,
        height: 30,
        flex:0.1
    },
    x: {
        fontSize: 15,
        textAlign: 'center',
        fontWeight: 'bold',

    },
    plusButton: {
        width: 50,
        height: 50,
        borderRadius: 30,
        borderWidth: 1,
        backgroundColor: 'lightblue',
        justifyContent: 'center',
        position: 'absolute',
        bottom: 5,
        right: 5
    },
    plusText: {
        textAlign: 'center',
        fontSize: 35,

    },
    values: {
        fontSize: 20,
        fontWeight: 'bold',
        marginLeft: 10
    },
    infoContainer:{
        flex:1,
        
    }


});

export default Cig
