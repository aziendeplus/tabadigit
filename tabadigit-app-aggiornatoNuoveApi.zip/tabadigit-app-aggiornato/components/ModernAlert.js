/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

import React from 'react';
import { StyleSheet, View, Text, Modal, TouchableOpacity } from 'react-native';
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { faTimes, faCheckCircle, faExclamationTriangle, faInfoCircle } from "@fortawesome/free-solid-svg-icons";
import { theme, commonStyles } from '../theme';

/**
 * Componente ModernAlert - Dialogo di avviso moderno
 * Sostituisce AwesomeAlert con un componente più moderno e coerente con il design system
 * 
 * @author Mandalà Giuseppe
 */
const ModernAlert = ({
  visible,
  title,
  message,
  onClose,
  type = 'info', // 'info', 'success', 'warning', 'error'
  confirmText = 'OK',
  onConfirm = null,
  cancelText = 'Annulla',
  onCancel = null,
  showCancel = false
}) => {
  // Determina l'icona e il colore in base al tipo
  const getAlertStyle = () => {
    switch(type) {
      case 'success':
        return {
          icon: faCheckCircle,
          color: theme.colors.success,
        };
      case 'warning':
        return {
          icon: faExclamationTriangle,
          color: theme.colors.accent,
        };
      case 'error':
        return {
          icon: faExclamationTriangle,
          color: theme.colors.error,
        };
      case 'info':
      default:
        return {
          icon: faInfoCircle,
          color: theme.colors.primary,
        };
    }
  };

  const alertStyle = getAlertStyle();

  return (
    <Modal
      transparent={true}
      visible={visible}
      animationType="fade"
      onRequestClose={onClose || onCancel || onConfirm}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <View style={styles.header}>
            <Text style={styles.title}>{title}</Text>
            {onClose && (
              <TouchableOpacity onPress={onClose} style={styles.closeButton}>
                <FontAwesomeIcon icon={faTimes} size={20} color="#666" />
              </TouchableOpacity>
            )}
          </View>
          
          <View style={styles.content}>
            <View style={[styles.iconContainer, { backgroundColor: alertStyle.color + '20' }]}>
              <FontAwesomeIcon icon={alertStyle.icon} size={30} color={alertStyle.color} />
            </View>
            
            <Text style={styles.message}>{message}</Text>
          </View>
          
          <View style={styles.buttonContainer}>
            {showCancel && onCancel && (
              <TouchableOpacity 
                style={[styles.button, styles.cancelButton]} 
                onPress={onCancel}
              >
                <Text style={styles.cancelButtonText}>{cancelText}</Text>
              </TouchableOpacity>
            )}
            
            <TouchableOpacity 
              style={[
                styles.button, 
                styles.confirmButton,
                { backgroundColor: alertStyle.color }
              ]} 
              onPress={onConfirm || onClose}
            >
              <Text style={styles.confirmButtonText}>{confirmText}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '85%',
    backgroundColor: theme.colors.background,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    ...theme.shadows.lg,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },
  title: {
    fontSize: theme.typography.fontSize.lg,
    fontWeight: 'bold',
    color: theme.colors.text,
  },
  closeButton: {
    padding: theme.spacing.xs,
  },
  content: {
    alignItems: 'center',
    marginBottom: theme.spacing.lg,
  },
  iconContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },
  message: {
    fontSize: theme.typography.fontSize.md,
    color: theme.colors.text,
    textAlign: 'center',
    lineHeight: 22,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  button: {
    paddingVertical: theme.spacing.md,
    paddingHorizontal: theme.spacing.lg,
    borderRadius: theme.borderRadius.md,
    minWidth: 100,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: theme.spacing.xs,
  },
  confirmButton: {
    backgroundColor: theme.colors.primary,
  },
  confirmButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: theme.typography.fontSize.md,
  },
  cancelButton: {
    backgroundColor: theme.colors.secondary,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  cancelButtonText: {
    color: theme.colors.text,
    fontSize: theme.typography.fontSize.md,
  },
});

export default ModernAlert;
