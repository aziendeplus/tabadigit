import React from 'react'
import {View, Text,StyleSheet} from 'react-native'
import * as Progress from 'react-native-progress'
import { colore } from '../colore'
const FlatlistFooter = () => {
    return (
        <View style = {styles.content}>
            <Progress.Circle size={25} indeterminate={true} color={colore} borderWidth={5}/>
        </View>
    )
}
const styles = StyleSheet.create({
    content:{
        justifyContent:'center',
        alignItems:'center',
        height:70
    }
})
export default FlatlistFooter
