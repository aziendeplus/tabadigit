import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Picker } from "@react-native-picker/picker";

import { TextInput } from "react-native-paper";
import { colore } from "../colore";

const TextInputDetail = ({
  title,
  value,
  editable,
  unchangeable,
  onChange,
  transform,
  labels,
  numberPad = false
}) => (
  <View style={styles.main}>
    <View style={styles.title}>
      <Text style={styles.text}>{title}</Text>
    </View>
    <View style={styles.textInputContainer}>
      {transform && editable ? (
        <View style={{ borderWidth: 0.5, borderRadius: 15 }}>
          <Picker
            style={{}}
            selectedValue={value}
            onValueChange={(item) => {
              onChange(item);
            }}
            mode="dropdown"
          >
            <Picker.Item label={value} value={value} key={value} />
            {labels
              ?.filter((label) => label !== value)
              .map((label) => {
                return (
                  <Picker.Item
                    label={label}
                    value={label}
                    key={(label) => label}
                  />
                );
              })}
          </Picker>
        </View>
      ) : (
        <TextInput
          theme={
            editable && unchangeable
              ? {
                  colors: {
                    primary: colore,
                    text: "#969696",
                  },
                }
              : { colors: { primary: colore } }
          }
          value={value}
          onChangeText={(text) => {
            onChange(text);
          }}
          editable={unchangeable ? false : editable}
          selectionColor="blue"
          keyboardType={numberPad ? "number-pad" : 'default'}
        />
      )}
    </View>
  </View>
);
const styles = StyleSheet.create({
  main: {
    width: "100%",
    flexDirection: "row",
    display: "flex",
    paddingHorizontal: 10,
    marginTop: 20,
    height: 70,
  },
  textInputContainer: {
    width: "80%",
    height: "100%",
    paddingLeft: 5,
  },
  title: {
    width: "20%",
    height: "100%",
    justifyContent: "center",
  },
  text: {
    fontSize: 17,
    fontWeight: "bold",
    color: colore,
  },
  textInput: {
    width: "100%",
    justifyContent: "center",
    alignItems: "center",
    fontWeight: "bold",
    backgroundColor: "white",
  },
  Picker: {},
});
export default TextInputDetail;
