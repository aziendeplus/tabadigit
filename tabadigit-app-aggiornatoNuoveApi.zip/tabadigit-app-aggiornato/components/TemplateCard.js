import { useNavigation } from "@react-navigation/native";
import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { colore } from "../colore";

const TemplateCard = ({ template }) => {
  const { itemNum, resolution, size, templateName } = template;
  const navigation = useNavigation();
  return (
    <TouchableOpacity
      style={styles.content}
      onPress={() => navigation.navigate("MulticomodityBinding", { template })}
    >
      <Text style={styles.title}>{templateName}</Text>
      <View style={styles.textContainer}>
        <Text style={styles.labelText}>N Prodotti: </Text>
        <Text style={styles.text}>{itemNum}</Text>
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.labelText}>Dimensioni: </Text>
        <Text style={styles.text}>{size}</Text>
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.labelText}>Risoluzione: </Text>
        <Text style={styles.text}>{resolution}</Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  content: {
    borderBottomWidth: 1,
    width: "100%",
    padding: 5,
    flexDirection: "column",
    height: 120,
    justifyContent: "center",
  },
  title: {
    fontSize: 17,
    fontWeight: "bold",
    textAlign: "center",
    marginVertical: 3,
    color: colore,
  },
  text: {
    fontSize: 15,
  },
  iconContainer: {
    position: "absolute",
    right: 0,
    top: 55,
  },
  textContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  labelText: {
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
});
export default TemplateCard;
