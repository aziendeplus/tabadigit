import React from "react";
import { View, StyleSheet, Text, TouchableHighlight } from "react-native";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { colore } from "../colore";
import { useNavigation } from "@react-navigation/native";
import AwesomeAlert from "react-native-awesome-alerts";

const Card = ({ icon, title, navigationPage, support }) => {
  const navigation = useNavigation();

  const [Alt, setAlt] = React.useState(false);

  var [isPress, setIsPress] = React.useState(false);

  const onPress = () => {
    if (navigationPage) {
      navigation.navigate(navigationPage)
    } else if (support) {
      setAlt(true)
    }
  }
  var touchProps = {
    activeOpacity: 1,
    underlayColor: colore,
    style: isPress ? styles.btnPress : styles.btnNormal,
    onHideUnderlay: () => setIsPress(false),
    onShowUnderlay: () => setIsPress(true),
  };

  return (
    <TouchableHighlight {...touchProps} onPress={onPress}>
      <View style={styles.block}>
        <FontAwesomeIcon icon={icon} size={25} color={isPress ? 'white' : colore} />
        <Text
          style={[
            styles.title,
            isPress ? { color: "white" } : { color: colore },
          ]}
        >
          {title}
        </Text>
        
      
      <AwesomeAlert
        overlayStyle={{ height: "100%" }}
        titleStyle={{ color: "red", fontWeight: "bold" }}
        messageStyle={{ textAlign: "center" }}
        contentContainerStyle={{ borderColor: colore, borderWidth: 2 }}
        show={Alt}
        title={"Supporto"}
        customView={<Text style={styles.message}>
              Se non trovate un prodotto segnalatecelo inviandoci il barcode e codice dei monopoli del prodotto, segnalateci anche se trovate un prezzo non corretto. 
              Inviateci una email a <Text style={styles.strongMessage}>supporto@tabadigit.it</Text> oppure tramite whatsapp al numero <Text style={styles.strongMessage}>3475974392</Text>
        </Text>}
        closeOnTouchOutside={true}
        closeOnHardwareBackPress={false}
        showConfirmButton={true}
        showCancelButton={true}
        cancelText="No"
        confirmText="Okay"
        confirmButtonColor={colore}
        onConfirmPressed={() => setAlt(false)}
        onDismiss={() => setAlt(false)}
        onCancelPressed={() => setAlt(false)}
        showProgress={true}
      />
      </View>

    </TouchableHighlight>
  );
};

const styles = StyleSheet.create({
  title: {
    fontSize: 14,
    fontWeight: "bold",
    marginTop: 20,
    textAlign: 'center'
  },
  btnNormal: {
    borderWidth: 1.5,
    borderRadius: 15,
    width: "45%",
    height: 150,
    borderColor: colore,
    margin: "2.5%",
  },
  btnPress: {
    borderWidth: 1.5,
    borderRadius: 15,
    width: "45%",
    height: 150,
    borderColor: colore,
    backgroundColor: colore,
    margin: "2.5%",
  },
  block: {
    width: "100%",
    height: "100%",
    justifyContent: "center",
    alignItems: "center",
  },
  
  message: {
    paddingTop: 5,
    color: '#7b7b7b',
    fontSize: 14
  },
  
  strongMessage: {
    paddingTop: 5,
    color: '#7b7b7b',
    fontSize: 14,
    fontWeight: 'bold'
  },
});

//TouchableOpacity.defaultProps = { activeOpacity: 0.3 };
export default Card;
