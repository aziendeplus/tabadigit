import React from "react";
import { TouchableHighlight } from "react-native";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { faPlus } from "@fortawesome/free-solid-svg-icons";
import { useNavigation } from "@react-navigation/native";

const PlusButton = () => {
  const navigation = useNavigation();
  return (
    <TouchableHighlight
      onPress={() => navigation.navigate("CreaProdotto")}
      style={{ marginRight: 20 }}
    >
      <FontAwesomeIcon icon={faPlus} size={25} color="white" />
    </TouchableHighlight>
  );
};

export default PlusButton;
