/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { theme, commonStyles } from '../theme';

/**
 * Componente Card modernizzato con il nuovo sistema di design
 * 
 * @author Mandalà Giuseppe
 */
const ModernCard = ({ icon, title, navigationPage, navigation, support }) => {
  const handlePress = () => {
    if (support) {
      // Logica per il supporto
      console.log("Supporto richiesto");
    } else if (navigationPage) {
      navigation.navigate(navigationPage);
    }
  };

  return (
    <TouchableOpacity 
      style={styles.card} 
      onPress={handlePress}
      activeOpacity={0.7}
    >
      <View style={styles.iconContainer}>
        <FontAwesomeIcon 
          icon={icon} 
          size={30} 
          color={theme.colors.primary} 
        />
      </View>
      <Text style={styles.title}>{title}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    ...commonStyles.card,
    width: '45%',
    height: 120,
    margin: '2.5%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.colors.card,
    borderRadius: theme.borderRadius.md,
    ...theme.shadows.md,
  },
  iconContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: theme.colors.secondary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: theme.spacing.sm,
  },
  title: {
    fontSize: theme.typography.fontSize.md,
    fontWeight: 'bold',
    color: theme.colors.text,
    textAlign: 'center',
  },
});

export default ModernCard;
