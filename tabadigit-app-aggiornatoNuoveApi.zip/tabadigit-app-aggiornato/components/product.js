import React from 'react'
import { StyleSheet, View, Text, TextInput, ScrollView } from 'react-native'

const Product = ({ item,amount,setAmount }) => {

    return (
        <View style={styles.container}>
            <View style={styles.textContainer}>
                <ScrollView
                style = {styles.scroll}
                >
                    <Text style={styles.nome}>{item.itemTitle}</Text>
                    <Text style={styles.details}>
                        Tipo: {item.custFeature1} {"\n"}
                        Prezzo: {item.price + '€'}
                    </Text>
                    
                    <View
                        style={styles.amountBox}
                    >
                        <Text style={{ fontWeight: 'bold', fontSize: 25 }}>Quantità: </Text>
                        <TextInput
                            keyboardType="number-pad"
                            onChangeText={setAmount}
                            value={amount!=="" && amount}
                            style={amount!=="" && amount!=undefined?[styles.amount,styles.BorderBottomGreen]:[styles.amount,styles.BorderBottomRed] }
                        ></TextInput>
                    </View>
                    <Text style={styles.totale}>Totale: {amount !== undefined && amount * item.price + '€'}</Text>
                </ScrollView>
            </View> 
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'white',
        width: '100%',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: 20,
    },
    nome: {
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 4
    },
    details: {
        marginTop: 5,
        fontSize: 17,
        marginBottom: 16,
    },
    amountBox: {
        width: '90%',
        flexDirection: 'row',
        marginTop: 10,
        alignItems: 'center'
    },
    amount: {
        borderBottomWidth: 1.5,
        flex: 0.3,
        marginLeft: 10,
        fontSize: 25,
        textAlign: 'center',
    },
    BorderBottomGreen:{
        borderBottomColor:"green"
    },
    BorderBottomRed:{
        borderBottomColor:"red"
    },
    totale: {
        fontSize: 25,
        fontWeight: 'bold',
        marginTop: 20
    },
    scroll:{
        width:'100%',
        height:'100%'
    },
    textContainer: {
        paddingHorizontal: 12,
        width: '100%',
        backgroundColor: 'white',
        flex: 0.6,
    }

})
export default Product
