import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { faAngleRight } from "@fortawesome/free-solid-svg-icons";
import { useNavigation } from "@react-navigation/native";
import { colore } from "../colore";

const Prodotto = ({ data, disabled }) => {
  const navigation = useNavigation();
  return (
    <TouchableOpacity
      style={styles.content}
      onPress={() => navigation.navigate("DettagliProdotto", { data: data })}
      disabled={disabled}
    >
      {!disabled && (
        <View style={styles.iconContainer}>
          <FontAwesomeIcon icon={faAngleRight} size={23}></FontAwesomeIcon>
        </View>
      )}
      <Text style={styles.title}>
        {data.Nome} (COD: {data.CodiceProdotto || data.productCode})
      </Text>
      <View style={styles.textContainer}>
        <Text style={styles.labelText}>Prezzo: </Text>
        <Text style={styles.text}>{data.Prezzo}</Text>
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.labelText}>Barcode: </Text>
        <Text style={styles.text}>{data.Barcode}</Text>
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.labelText}>Type: </Text>
        <Text style={styles.text}>{data.attrName}</Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  content: {
    borderBottomWidth: 1,
    width: "100%",
    padding: 5,
    flexDirection: "column",
    height: 120,
    justifyContent: "center",
  },
  title: {
    fontSize: 17,
    fontWeight: "bold",
    textAlign: "center",
    marginVertical: 3,
    color: colore,
  },
  text: {
    fontSize: 15,
    //fontWeight:'bold'
  },
  iconContainer: {
    position: "absolute",
    right: 0,
    top: 55,
  },
  textContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  labelText: {
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
    //color:colore
  },
});
export default Prodotto;
