/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Alert } from 'react-native';
import { TextInput } from 'react-native-paper';
import AwesomeButton from 'react-native-really-awesome-button';
import Prodotto from './Prodotto';
import { colore } from '../colore';

/**
 * Componente per la gestione degli ordini di prodotti
 * Migliorato con validazione input e gestione quantità
 * 
 * @author Mandalà Giuseppe
 */
function ProductOrder({ item, onChangeText, handleRemove }) {
  const [text, setText] = useState(item.unitaminima.toString());
  const [isValid, setIsValid] = useState(true);
  
  // Validazione iniziale
  useEffect(() => {
    validateQuantity(item.unitaminima.toString());
  }, []);

  // Funzione di validazione della quantità
  const validateQuantity = (value) => {
    const numValue = parseFloat(value);
    
    // Verifica se è un numero valido e se rispetta l'unità minima
    const valid = !isNaN(numValue) && numValue >= item.unitaminima;
    setIsValid(valid);
    
    return valid;
  };

  // Gestione del cambio di testo con validazione
  const handleTextChange = (value) => {
    // Rimuove caratteri non numerici, tranne il punto decimale
    // e sostituisce la virgola con il punto
    const newValue = value.replace(',', '.').replace(/[^\d.]/g, "");
    
    // Evita input con più di un punto decimale
    const parts = newValue.split('.');
    const cleanValue = parts.length > 2 
      ? parts[0] + '.' + parts.slice(1).join('')
      : newValue;
    
    // Aggiorna lo stato e notifica il componente padre
    setText(cleanValue);
    
    // Valida la quantità
    const isValidQuantity = validateQuantity(cleanValue);
    
    // Passa il valore al componente padre solo se valido
    const numValue = parseFloat(cleanValue) || 0;
    onChangeText(numValue);
  };

  // Conferma rimozione con alert
  const confirmRemove = () => {
    Alert.alert(
      "Conferma rimozione",
      `Sei sicuro di voler rimuovere ${item.Nome} dall'ordine?`,
      [
        {
          text: "Annulla",
          style: "cancel"
        },
        { 
          text: "Rimuovi", 
          onPress: () => handleRemove(item.Barcode),
          style: "destructive"
        }
      ]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.containerInput}>
        <TextInput
          style={[
            styles.textInput,
            !isValid && styles.textInputError
          ]}
          theme={{ colors: { primary: colore } }}
          value={text}
          onChangeText={handleTextChange}
          placeholder="Pezzi"
          allowFontScaling
          keyboardType="numeric"
        />
        {!isValid && (
          <Text style={styles.textError}>
            Unità minima {item.unitaminima}
          </Text>
        )}
      </View>
      <View style={styles.buttonContainer}>
        <AwesomeButton
          backgroundDarker="#e8e8e8"
          width="100%"
          type="primary"
          backgroundColor={colore}
          borderRadius={0}
          borderBottomRightRadius={5}
          height={38}
          raiseLevel={3}
          onPress={confirmRemove}
        >
          <Text style={styles.x}>X</Text>
        </AwesomeButton>
      </View>
      <View style={styles.product}>
        <Prodotto
          data={item}
          disabled={true}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flexDirection: 'row', 
    justifyContent: 'center',
    marginBottom: 10,
    borderRadius: 5,
    backgroundColor: '#fff',
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
  },
  containerInput: {
    position: 'absolute',
    bottom: 30,
    right: 10,
    zIndex: 2
  },
  textInput: { 
    height: 40,
    width: 100,
    fontSize: 17, 
    backgroundColor: 'white', 
    textAlign: 'center'
  },
  textInputError: {
    borderColor: 'red',
    borderWidth: 1
  },
  buttonContainer: { 
    width: 38, 
    position: 'absolute', 
    left: 0, 
    top: 0 
  },
  x: { 
    color: 'white',
    fontWeight: 'bold'
  },
  product: { 
    width: '100%' 
  },
  textError: {
    color: 'red',
    fontSize: 12,
    textAlign: 'center'
  }
});

export default ProductOrder;
