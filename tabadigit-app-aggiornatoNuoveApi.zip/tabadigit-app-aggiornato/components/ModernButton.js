/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { theme, commonStyles } from '../theme';

/**
 * Componente ModernButton - Pulsante moderno con stile migliorato
 * Sostituisce AwesomeButton con un componente più moderno e coerente con il design system
 * 
 * @author Mandalà Giuseppe
 */
const ModernButton = ({ 
  title, 
  onPress, 
  disabled = false, 
  type = 'primary', 
  icon = null,
  width = '100%',
  height = 50,
  style = {}
}) => {
  // Determina lo stile in base al tipo
  const getButtonStyle = () => {
    switch(type) {
      case 'secondary':
        return {
          backgroundColor: theme.colors.secondary,
          borderWidth: 1,
          borderColor: theme.colors.primary,
        };
      case 'danger':
        return {
          backgroundColor: theme.colors.error,
        };
      case 'success':
        return {
          backgroundColor: theme.colors.success,
        };
      case 'accent':
        return {
          backgroundColor: theme.colors.accent,
        };
      case 'primary':
      default:
        return {
          backgroundColor: theme.colors.primary,
        };
    }
  };

  // Determina lo stile del testo in base al tipo
  const getTextStyle = () => {
    switch(type) {
      case 'secondary':
        return {
          color: theme.colors.primary,
        };
      default:
        return {
          color: '#ffffff',
        };
    }
  };

  return (
    <TouchableOpacity
      style={[
        styles.button,
        getButtonStyle(),
        { width, height },
        disabled && styles.buttonDisabled,
        style
      ]}
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.8}
    >
      <View style={styles.buttonContent}>
        {icon && <View style={styles.iconContainer}>{icon}</View>}
        <Text style={[styles.buttonText, getTextStyle(), disabled && styles.buttonTextDisabled]}>
          {title}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: theme.borderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
    ...theme.shadows.sm,
    elevation: 3,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    fontSize: theme.typography.fontSize.md,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  buttonDisabled: {
    backgroundColor: theme.colors.disabled,
    elevation: 0,
  },
  buttonTextDisabled: {
    color: '#999999',
  },
  iconContainer: {
    marginRight: theme.spacing.sm,
  }
});

export default ModernButton;
