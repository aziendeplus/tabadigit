import React from 'react'
import { StyleSheet, View,StatusBar,Platform} from 'react-native'
import { colore } from '../colore'
import * as Progress from 'react-native-progress'
const Loading = () => {
    return (
        <View style={styles.container}>
            <Progress.Circle size={45} indeterminate={true} borderWidth={50} color={colore}/> 
        </View>
    )
}
const styles = StyleSheet.create({
    container:{
        justifyContent:'center',
        alignItems:'center',
        height:'100%',
        width:'100%',
        zIndex:20,
        position:'absolute',
        backgroundColor:'#ebe6e6',
        opacity:0.8,
        paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
    }
})
export default Loading
