import React from "react";
import authReducer from "./store/authReducer";
import thunk from "redux-thunk";
import { createStore, applyMiddleware, compose, combineReducers } from "redux";
import { Provider } from "react-redux";
import App from "./App";

const rootReducer = combineReducers({
  auth: authReducer,
});
const store = createStore(rootReducer, compose(applyMiddleware(thunk)));

export default () => (
  <Provider store={store}>
    <App />
  </Provider>
);
