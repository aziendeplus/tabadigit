import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import QRpage from "../screens/QRpage";
import Main from "../screens/Main";
import Collega from "../screens/CardScreens/Collega";

import Prodotti from "../screens/CardScreens/Prodotti";

const StackNav = () => {
    const Stac = createStackNavigator();
    return (
        <Stac.Navigator>
            <Stac.Screen
                name="Main"
                component={Main}
                options={{
                    headerShown: false
                }}
            />

            <Stac.Screen
                name="Collega"
                component={Collega}
                options={{
                    headerShown: false
                }}
            />

            <Stac.Screen
                name="QRpage"
                component={QRpage}
                options={{
                    headerShown: false
                }}
            />
            <Stac.Screen
                name="Prodotti"
                component={Prodotti}
                options={{
                    headerShown: false
                }}
            />



        </Stac.Navigator>

    )
}

export default StackNav
