/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 * 
 * Questo file fa parte dell'applicazione Tabadigit per la gestione delle etichette elettroniche.
 */
