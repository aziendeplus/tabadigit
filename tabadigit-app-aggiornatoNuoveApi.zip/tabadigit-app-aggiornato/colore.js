/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

// Importa il colore dal nuovo sistema di temi
import { colore as themeColor } from './theme';

// Esporta il colore per retrocompatibilità
export var colore = themeColor;

// Mantiene la funzione setColore per retrocompatibilità
export function setColore(newColore) {
  colore = newColore;
  // Rimuovo l'alert che potrebbe disturbare l'esperienza utente
  console.log("Colore aggiornato a: " + newColore);
}
