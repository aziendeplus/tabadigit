/* * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe * www.tabadigit.it *
Tutti i diritti riservati. */

import { SERVER, SERVER_FT, SERVER_IP, API_PATH } from "./constants";
import Papa from "papaparse";
import { signIn } from "./store/authActions";

// Funzione di utilità per gestire gli errori nelle chiamate API
const handleApiError = (error, functionName) => {
  console.error(`Errore in ${functionName}:`, error);
  // Qui si potrebbe implementare un sistema di logging degli errori
  return { success: false, error: error.message, code: 'ERROR', data: null };
};

// Funzione di utilità per verificare la risposta
const validateResponse = (response, functionName) => {
  if (!response || !response.ok) {
    console.error(`Risposta non valida in ${functionName}:`, response);
    return false;
  }
  return true;
};

// Funzione per aggiungere l'header della lingua
const getHeaders = (token, language = 'it') => {
  const headers = {
    "Content-Type": "application/json"
  };
  
  if (token) {
    headers["Authorization"] = token;
  }
  
  headers["Language"] = language;
  
  return headers;
};

export async function getPublicKey() {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/user/getErpPublicKey`);
    if (!validateResponse(response, 'getPublicKey')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'getPublicKey');
  }
}

export async function login(username, password) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/user/login`, {
      method: "post",
      body: JSON.stringify({ account: username, password, loginType: 3 }),
      headers: getHeaders()
    });
    if (!validateResponse(response, 'login')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'login');
  }
}

export async function logout(username) {
  try {
    const response = await fetch(
      `${SERVER}${API_PATH}/user/logout?username=${username}`,
      {
        method: "get",
        headers: getHeaders()
      }
    );
    if (!validateResponse(response, 'logout')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'logout');
  }
}

export async function getUser(token, userId) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/user/get/${userId}`, {
      method: "get",
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'getUser')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'getUser');
  }
}

export async function getStores(token) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/store/getDataPermissions`, {
      method: "get",
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'getStores')) {
      return null;
    }

    const responseJson = await response.json();

    if (responseJson?.data?.length > 0) return responseJson.data;
    return null;
  } catch (error) {
    handleApiError(error, 'getStores');
    return null;
  }
}

/**
 * examples:
 *
 *  const stores = await getStores(token)
 *  const response = await bindItems(token, stores[1].storeId, "800361373", "5410706851168")
 */
export async function bindItems(token, storeId, eslBarcode, itemBarcode) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/binding/bindItemAndEsl`, {
      method: "post",
      body: JSON.stringify({
        apMac: null,
        itemBarCode: itemBarcode,
        merchantId: null,
        priceTagCode: eslBarcode,
        storeId: storeId,
      }),
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'bindItems')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'bindItems');
  }
}

export async function getEslInfo(token, storeId, eslBarcode) {
  try {
    console.log(eslBarcode);
    const response = await fetch(
      `${SERVER_IP}${API_PATH}/esl/queryEslStatus?barCode=${eslBarcode}`,
      {
        method: "get",
        headers: getHeaders(token)
      }
    );
    if (!validateResponse(response, 'getEslInfo')) {
      return null;
    }

    const responseJson = await response.json();
    if (responseJson?.data) return responseJson?.data;
    return null;
  } catch (error) {
    handleApiError(error, 'getEslInfo');
    return null;
  }
}

export async function getBindInfo(token, storeId, eslBarcode) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/binding/findBinds`, {
      method: "post",
      body: JSON.stringify({
        apSignalEnd: null,
        apSignalStart: null,
        batteryLevel: null,
        deviceType: null,
        itemBarCode: null,
        itemTitle: null,
        model: null,
        priceTagCode: eslBarcode,
        shelfNo: null,
        state: null,
        storeId,
        page: 1,
        pageSize: 10
      }),
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'getBindInfo')) {
      return null;
    }

    const responseJson = await response.json();
    if (responseJson?.data?.list?.length) return responseJson?.data?.list[0];
    return null;
  } catch (error) {
    handleApiError(error, 'getBindInfo');
    return null;
  }
}

/**
 *   const stores = await getStores(token)
 *   const response = await unbindItem(token, stores[1].storeId, "800361373")
 *   console.log(response)
 */
export async function unbindItem(token, storeId, eslBarcode) {
  try {
    const bindInfo = await getBindInfo(token, storeId, eslBarcode);
    if (!bindInfo) {
      return { success: false, code: 'ERROR', message: 'Informazioni di binding non trovate' };
    }
    
    const response = await fetch(`${SERVER_IP}${API_PATH}/binding/batchUnbind`, {
      method: "post",
      body: JSON.stringify({
        storeId: storeId,
        bindIds: [bindInfo?.id]
      }),
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'unbindItem')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'unbindItem');
  }
}

export async function createItem(token, data) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/item/batchImportItem`, {
      method: "post",
      body: JSON.stringify({
        storeId: data.storeId,
        merchantId: data.merchantId,
        agencyId: data.agencyId,
        unitName: data.unitName || 1,
        itemList: [data]
      }),
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'createItem')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'createItem');
  }
}

export async function getItemById(token, id) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/item/item/${id}`, {
      method: "get",
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'getItemById')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'getItemById');
  }
}

export async function getItemByStoreBarcode(token, storeId, barCode) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/item/getItemByBarcode?storeId=${storeId}&barCode=${barCode}`, {
      method: "get",
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'getItemByStoreBarcode')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'getItemByStoreBarcode');
  }
}

export async function getCategories(token) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/attrCategory/findList`, {
      method: "get",
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'getCategories')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'getCategories');
  }
}

export async function getTemplates(token) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/store/queryStoreTemplate`, {
      method: "post",
      body: JSON.stringify({}),
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'getTemplates')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'getTemplates');
  }
}

const ITEM_PER_PAGE = 10;

export async function getProductByBarCode(token, storeId, barCode) {
  try {
    const response = await fetch(
      `${SERVER_IP}${API_PATH}/item/getItemByBarcode?storeId=${storeId}&barCode=${barCode}`,
      {
        method: "get",
        headers: getHeaders(token)
      }
    );
    if (!validateResponse(response, 'getProductByBarCode')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'getProductByBarCode');
  }
}

export async function getProductByAms(token, storeId, amsCode) {
  try {
    const response = await fetch(
      `${SERVER_IP}${API_PATH}/item/getItemByProductCode?storeId=${storeId}&productCode=${amsCode}`,
      {
        method: "get",
        headers: getHeaders(token)
      }
    );
    if (!validateResponse(response, 'getProductByAms')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'getProductByAms');
  }
}

export async function getProducts(token, page, storeID, barCode, nome) {
  try {
    const queryParams = new URLSearchParams();
    queryParams.append('storeId', storeID);
    queryParams.append('page', page);
    queryParams.append('pageSize', ITEM_PER_PAGE);
    
    if (barCode) {
      queryParams.append('barCode', barCode);
    }
    
    if (nome) {
      queryParams.append('itemTitle', nome);
    }
    
    const response = await fetch(
      `${SERVER_IP}${API_PATH}/item/queryStoreItems?${queryParams.toString()}`,
      {
        method: "get",
        headers: getHeaders(token)
      }
    );
    if (!validateResponse(response, 'getProducts')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'getProducts');
  }
}

export async function getMulticomodityTemplates(token, page, storeId, name) {
  try {
    const queryParams = new URLSearchParams();
    queryParams.append('storeId', storeId);
    queryParams.append('page', page);
    queryParams.append('pageSize', ITEM_PER_PAGE);
    
    if (name) {
      queryParams.append('name', name);
    }
    
    const response = await fetch(
      `${SERVER_IP}${API_PATH}/store/queryStoreTemplate?${queryParams.toString()}`,
      {
        method: "get",
        headers: getHeaders(token)
      }
    );
    if (!validateResponse(response, 'getMulticomodityTemplates')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'getMulticomodityTemplates');
  }
}

export async function bindMulti(
  token,
  storeId,
  eslBarcode,
  item1,
  item2,
  templateId
) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/binding/bindMultiCommodityTemplate`, {
      method: "post",
      body: JSON.stringify({
        priceTagCode: eslBarcode,
        itemOrders: [
          {
            itemCode: item1,
            order: 0,
          },
          {
            itemCode: item2,
            order: 1,
          },
        ],
        storeId: storeId,
        templateId,
      }),
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'bindMulti')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'bindMulti');
  }
}

export async function searchProducts(token, page, storeID, searchText) {
  try {
    const queryParams = new URLSearchParams();
    queryParams.append('storeId', storeID);
    queryParams.append('page', page);
    queryParams.append('pageSize', ITEM_PER_PAGE);
    queryParams.append('searchText', searchText);
    
    const response = await fetch(`${SERVER_IP}${API_PATH}/item/searchItems?${queryParams.toString()}`, {
      method: "get",
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'searchProducts')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'searchProducts');
  }
}

export async function invert(token, storeId, eslCode) {
  try {
    const bindInfo = await getBindInfo(token, storeId, eslCode);
    if (!bindInfo) {
      return { success: false, code: 'ERROR', message: 'Informazioni di binding non trovate' };
    }
    
    const response = await fetch(
      `${SERVER_IP}${API_PATH}/esl/invertEsl`,
      {
        method: "post",
        body: JSON.stringify({
          storeId: storeId,
          eslBarcode: eslCode
        }),
        headers: getHeaders(token)
      }
    );
    if (!validateResponse(response, 'invert')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'invert');
  }
}

export async function changeProduct(token, id, storeID, newProduct) {
  try {
    // Utilizziamo l'API di importazione batch per aggiornare il prodotto
    const response = await fetch(`${SERVER_IP}${API_PATH}/item/batchImportItem`, {
      method: "post",
      body: JSON.stringify({
        storeId: storeID,
        merchantId: newProduct.merchantId,
        agencyId: newProduct.agencyId,
        unitName: newProduct.unitName || 1,
        itemList: [newProduct]
      }),
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'changeProduct')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'changeProduct');
  }
}

export async function loadingStoreInfo(token, storeID) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/esl/queryEslStatus`, {
      method: "post",
      body: JSON.stringify({
        storeId: storeID
      }),
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'loadingStoreInfo')) {
      return { data: [], errors: ['Errore di connessione al server'] };
    }
    
    const responseJson = await response.json();
    if (responseJson?.data) {
      // Convertiamo il formato della risposta per mantenere la compatibilità
      const eslData = responseJson.data.map(esl => [
        esl.eslBarcode,
        esl.model,
        esl.batteryLevel,
        esl.lastUpdateTime,
        esl.status === 'online' ? 'Online' : 'Offline'
      ]);
      
      return { data: eslData, errors: [] };
    }
    
    return { data: [], errors: [] };
  } catch (error) {
    handleApiError(error, 'loadingStoreInfo');
    return { data: [], errors: [error.message] };
  }
}

export async function refreshEsl(token, storeId, eslBarcode) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/esl/forceRefreshByBarcode`, {
      method: "post",
      body: JSON.stringify({
        storeId: storeId,
        eslBarcode: eslBarcode
      }),
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'refreshEsl')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'refreshEsl');
  }
}

export async function refreshAllEsls(token, storeId) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/esl/batchRestart`, {
      method: "post",
      body: JSON.stringify({
        storeId: storeId
      }),
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'refreshAllEsls')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'refreshAllEsls');
  }
}

export async function controlEslLed(token, storeId, eslBarcode, duration = 10, color = "red") {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/esl/executeLed`, {
      method: "post",
      body: JSON.stringify({
        storeId: storeId,
        eslBarcode: eslBarcode,
        duration: duration,
        color: color
      }),
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'controlEslLed')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'controlEslLed');
  }
}

export async function stopEslLed(token, storeId, eslBarcode) {
  try {
    const response = await fetch(`${SERVER_IP}${API_PATH}/esl/stopFlashingWithEslBarcode`, {
      method: "post",
      body: JSON.stringify({
        storeId: storeId,
        eslBarcode: eslBarcode
      }),
      headers: getHeaders(token)
    });
    if (!validateResponse(response, 'stopEslLed')) {
      return { success: false, code: 'ERROR', message: 'Errore di connessione al server' };
    }
    return response.json();
  } catch (error) {
    return handleApiError(error, 'stopEslLed');
  }
}
