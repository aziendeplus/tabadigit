/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { colore } from '../colore';

/**
 * Componente ErrorBoundary per catturare gli errori nell'applicazione
 * e mostrare un'interfaccia di fallback invece di far crashare l'app
 * 
 * @author Mandalà Giuseppe
 */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      hasError: false,
      error: null,
      errorInfo: null
    };
  }

  static getDerivedStateFromError(error) {
    // Aggiorna lo stato in modo che il prossimo render mostri l'UI di fallback
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    // Puoi anche registrare l'errore in un servizio di reporting degli errori
    console.error('ErrorBoundary ha catturato un errore:', error, errorInfo);
    this.setState({ errorInfo });
    
    // Qui potresti inviare l'errore a un servizio di logging remoto
  }

  resetError = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
  }

  render() {
    if (this.state.hasError) {
      // Puoi renderizzare qualsiasi UI di fallback
      return (
        <View style={styles.container}>
          <Text style={styles.title}>Oops! Qualcosa è andato storto</Text>
          <Text style={styles.message}>
            L'applicazione ha riscontrato un problema. Non preoccuparti, i tuoi dati sono al sicuro.
          </Text>
          <Text style={styles.errorText}>
            {this.state.error && this.state.error.toString()}
          </Text>
          <TouchableOpacity style={styles.button} onPress={this.resetError}>
            <Text style={styles.buttonText}>Riprova</Text>
          </TouchableOpacity>
        </View>
      );
    }

    return this.props.children;
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colore,
    marginBottom: 20,
  },
  message: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
    color: '#333',
  },
  errorText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 30,
    padding: 10,
    backgroundColor: '#f8f8f8',
    borderRadius: 5,
    width: '100%',
  },
  button: {
    backgroundColor: colore,
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ErrorBoundary;
