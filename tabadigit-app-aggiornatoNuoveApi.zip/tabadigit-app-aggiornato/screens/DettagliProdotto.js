import React, { useContext, useState, useEffect } from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import TextInputDetail from "../components/TextInputDetail";
import AwesomeButton from "react-native-really-awesome-button";
import { colore } from "../colore";
import {
  apiWithRetry,
  changeProduct,
  getCategories,
  getItemByStoreBarcode,
  getTemplates,
} from "../api";
import AwesomeAlert from "react-native-awesome-alerts";
import { useDispatch, useSelector } from "react-redux";
import CopyButton from "../components/CopyButton";

const DettagliProdotto = ({ route }) => {
  const { token, selectedStore } = useSelector((rootState) => rootState.auth);
  const [product, setProduct] = useState();
  const [categories, setCategories] = useState();
  const [templates, setTemplates] = useState();
  const [alert, setAlert] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState();
  const [selectedTemplate, setSelectedTemplate] = useState();
  const [selectedPrice, setSelectedPrice] = useState();
  const [editable, setEditable] = useState(false);
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();

  useEffect(() => {
    async function fetch() {
      try {
        const productBarCode = route.params.data.Barcode;
        const responseJSON = await apiWithRetry(
          () => getItemByStoreBarcode(token, selectedStore, productBarCode),
          dispatch
        );

        setProduct(responseJSON.data);
        const categoriesResponse = await getCategories(token);

        setCategories(categoriesResponse.data);

        const templatesResponse = await getTemplates(token);
        setTemplates(templatesResponse.data);
      } catch (error) {
        console.error(error);
        setAlert(true);
      }
    }

    fetch();
  }, [route.params]);

  const setTemplate = (value) => {
    setSelectedTemplate(templates.find((t) => t.attrName === value));
  };

  function setCategory(value) {
    setSelectedCategory(categories.find((c) => c.categoryName === value));
    setSelectedTemplate(templates.find((t) => t.categoryName === value));
  }

  async function onSubmit() {
    //setLoading(true);
    try {
      await changeProduct(token, route.params.data.id, selectedStore, {
        ...product,
        price: selectedPrice,
        attrCategory: selectedCategory?.categoryName ?? product.attrCategory,
        attrName: selectedTemplate?.attrName ?? product.attrName,
      });
    } catch (error) {
      console.error(error);
      setAlert(true);
    }
    setEditable(false);
    //setLoading(false);
  }

  let templatesOption;

  if (product) {
    const categoryToFilter =
      selectedCategory?.categoryName ?? product.attrCategory;

    templatesOption = templates
      ?.filter((t) => t.categoryName === categoryToFilter)
      ?.map((t) => t.attrName);
  }

  const onChangePrice = (value) => {
    setSelectedPrice(value.replace(",", ".").replace(/[^\d.]/, ""));
  };

  return (
    <View style={styles.main}>
      <AwesomeAlert
        overlayStyle={{ height: "100%" }}
        show={alert}
        showProgress={alert}
        title="ERRORE"
        message="Errore durante la lettura del prodotto"
        closeOnTouchOutside={true}
        closeOnHardwareBackPress={false}
        showConfirmButton={true}
        confirmText="OK"
        confirmButtonColor={colore}
        onConfirmPressed={() => setAlert(false)}
        onDismiss={() => setAlert(false)}
      />
      {product && (
        <>
          <ScrollView style={{ width: "100%" }}>
            <View
              style={{
                width: "100%",
                marginVertical: 20,
                alignItems: "center",
                flexDirection: "row",
                justifyContent: "space-evenly",
              }}
            >
              <Text style={styles.title}>Duplica prodotto</Text>
              <CopyButton product={product} />
            </View>
            <TextInputDetail
              title="Nome"
              value={product.itemTitle}
              unchangeable={true}
              editable={editable}
            />
            <TextInputDetail
              title="Prezzo"
              value={selectedPrice?.toString() ?? product.price.toString()}
              editable={editable}
              onChange={onChangePrice}
            />
            <TextInputDetail
              title="Codice AMS"
              value={product.productCode}
              unchangeable={true}
              editable={editable}
            />
            <TextInputDetail
              title="Barcode"
              value={product.barCode}
              unchangeable={true}
              editable={editable}
            />
            <TextInputDetail
              title="Tipologia"
              value={product.custFeature1}
              unchangeable={true}
              editable={editable}
            />
            <TextInputDetail
              title="Categoria template"
              value={selectedCategory?.categoryName ?? product.attrCategory}
              unchangeable={true}
              editable={editable}
              onChange={setCategory}
              transform={true}
              labels={categories?.map((c) => c.categoryName)}
            />
            <TextInputDetail
              title="Template"
              value={selectedTemplate?.attrName ?? product.attrName}
              editable={editable}
              onChange={setTemplate}
              transform={true}
              labels={templatesOption}
            />
            <TextInputDetail
              title="Unità"
              value={product.custFeature5}
              unchangeable={true}
              editable={editable}
            />
            <TextInputDetail
              title="Prezzo al Kg"
              value={product.custFeature2}
              unchangeable={true}
              editable={editable}
            />
            <TextInputDetail
              title="Unita minima"
              value={product.custFeature3}
              unchangeable={true}
              editable={editable}
            />
            <TextInputDetail
              title="Tipo pacchetto"
              value={product.custFeature4}
              unchangeable={true}
              editable={editable}
            />
          </ScrollView>
          <View
            style={{ width: "100%", marginVertical: 20, alignItems: "center" }}
          >
            <View style={{ width: "60%" }}>
              <AwesomeButton
                backgroundDarker="#e8e8e8"
                width="100%"
                type="primary"
                backgroundColor={colore}
                borderRadius={6}
                height={60}
                raiseLevel={5}
                progress={editable}
                onPress={
                  editable
                    ? (next) => {
                        onSubmit();
                        next();
                      }
                    : () => {
                        setEditable(true);
                      }
                }
              >
                {editable ? (
                  <Text style={styles.buttonText}>Salva</Text>
                ) : (
                  <Text style={styles.buttonText}>Cambia</Text>
                )}
                {/*loading && (
                  <Progress.Circle
                    size={30}
                    borderWidth={5}
                    indeterminate={true}
                    color="white"
                  />
                )*/}
              </AwesomeButton>
            </View>
          </View>
        </>
      )}
    </View>
  );
};
const styles = StyleSheet.create({
  main: {
    width: "100%",
    height: "100%",
    backgroundColor: "white",
  },
  buttonText: { fontSize: 20, fontWeight: "bold", color: "white" },
});
export default DettagliProdotto;
