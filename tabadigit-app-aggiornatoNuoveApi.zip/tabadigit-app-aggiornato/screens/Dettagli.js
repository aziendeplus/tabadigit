/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

import React, { useCallback, useContext, useState } from "react";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";
import AwesomeAlert from "react-native-awesome-alerts";
import { ScrollView } from "react-native-gesture-handler";
import AwesomeButton from "react-native-really-awesome-button";
import { apiWithRetry, getEslInfo } from "../api";
import { colore } from "../colore";
import InputCode from "../components/InputCode";
import * as Progress from "react-native-progress";
import { useDispatch, useSelector } from "react-redux";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { faLightbulb } from "@fortawesome/free-solid-svg-icons";
import LedFlashControl from "../components/LedFlashControl";

const Dettagli = ({}) => {
  const { token, selectedStore } = useSelector((rootState) => rootState.auth);
  const [eslCode, setSESLCode] = useState();
  const [loading, setLoading] = useState(false);
  const [details, setDetails] = useState();
  const [error, setError] = useState();
  const [showLedControl, setShowLedControl] = useState(false);
  const dispatch = useDispatch();

  const onPress = useCallback(async () => {
    setLoading(true);
    try {
      const apiDetails = await apiWithRetry(
        () => getEslInfo(token, selectedStore, eslCode),
        dispatch
      );
      console.log("ICooa", apiDetails);

      if (!apiDetails) setError("Nessuna etichetta trovata. Store sbagliato?");
      else setDetails(apiDetails);
    } catch (err) {
      console.error(err);
      setError("Si è presentato un problema durante la richiesta");
    } finally {
      setLoading(false);
    }
  }, [eslCode, token, selectedStore]);

  const flushError = useCallback(() => setError(), []);

  const connected = details?.items?.length > 0 ? true : false;

  return (
    <View style={styles.main}>
      {error && (
        <AwesomeAlert
          titleStyle={{ color: "red", fontWeight: "bold" }}
          messageStyle={{ textAlign: "center" }}
          contentContainerStyle={{ borderColor: colore, borderWidth: 2 }}
          overlayStyle={{ height: "100%" }}
          show={!!error}
          title={"Errore"}
          message={error}
          closeOnTouchOutside={true}
          closeOnHardwareBackPress={false}
          showConfirmButton={true}
          confirmText="OK"
          confirmButtonColor={colore}
          onConfirmPressed={flushError}
          onDismiss={flushError}
          showProgress={true}
        />
      )}
      
      {details && (
        <LedFlashControl 
          eslBarcode={details.tagBarCode}
          visible={showLedControl}
          onClose={() => setShowLedControl(false)}
        />
      )}

      <View style={styles.input}>
        <InputCode
          id={13}
          value={eslCode}
          setValue={setSESLCode}
          label="Codice ESL"
        />

        <View style={styles.button}>
          <AwesomeButton
            backgroundDarker="#e8e8e8"
            width="100%"
            type="primary"
            raiseLevel={4}
            backgroundColor={colore}
            borderRadius={6}
            height={60}
            raiseLevel={3}
            progress
            onPress={(next) => {
              onPress();
              next();
            }}
            disabled={!eslCode}
          >
            {/*loading ? (
              <Progress.Circle
                size={30}
                borderWidth={5}
                indeterminate={true}
                color="white"
              />
            ) : (
              <Text style={styles.buttonText}>Leggi</Text>
            )*/}
            <Text style={styles.buttonText}>Leggi</Text>
          </AwesomeButton>
        </View>
      </View>
      {details && (
        <ScrollView style={styles.details}>
          <View style={styles.detailHeader}>
            <Text style={styles.detail}>
              Barcode: <Text>{details.tagBarCode}</Text>
            </Text>
            <TouchableOpacity 
              style={styles.flashButton}
              onPress={() => setShowLedControl(true)}
            >
              <FontAwesomeIcon icon={faLightbulb} size={20} color={colore} />
              <Text style={styles.flashButtonText}>Flash LED</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.detail}>
            Ultima modifica: {details.lastCommuTime}
          </Text>
          <Text style={styles.detail}>Livello Batteria: {details.battery}</Text>
          <Text style={styles.detail}>
            Collegato: {connected ? "Si" : "No"}
          </Text>
          <Text style={styles.detail}>MAC: {details.mac}</Text>
          <Text style={styles.detail}>Modello: {details.model}</Text>
          {connected && (
            <Text style={styles.detail}>
              Connesso a {details.items.length} prodotti
            </Text>
          )}
          {connected &&
            details.items.map((item, index) => (
              <>
                <Text style={[{ marginTop: 20 }, styles.detail]}>
                  {" "}
                  ---- Prodotto {index + 1} ----
                </Text>
                <Text style={styles.detail}>Titolo: {item.itemTitle}</Text>
                <Text style={styles.detail}>Prezzo: {item.itemPrice}</Text>
                <Text style={styles.detail}>
                  Codice Prodotto: {item.itemBarCode}
                </Text>
              </>
            ))}
        </ScrollView>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  main: {
    flex: 1,
    alignContent: "center",
    justifyContent: "center",
    paddingHorizontal: 15,
    backgroundColor: "white",
    alignItems: "center",
  },
  button: {
    marginTop: 20,
    width: "100%",
  },
  input: {
    flex: 1,
    alignContent: "center",
    justifyContent: "center",
    width: "100%",
    alignItems: "center",
  },
  buttonText: { fontSize: 19, fontWeight: "bold", color: "white" },
  details: {
    flex: 1,
    width: "100%",
  },
  detail: {
    fontSize: 18,
    marginBottom: 5,
  },
  detailHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
    width: "100%",
  },
  flashButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f8f8f8",
    padding: 8,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: colore,
  },
  flashButtonText: {
    color: colore,
    marginLeft: 5,
    fontWeight: "bold",
  },
});

export default Dettagli;
