import React, { useEffect, useRef, useState } from "react";
import { View, Text, StyleSheet, Button, Vibration } from "react-native";
import { BarCodeScanner } from "expo-barcode-scanner";

const QRpage = ({ navigation, route }) => {
  const goBack = () => {
    navigation.goBack();
  };

  const scanned = useRef();
  const [hasPermission, setHasPermission] = useState(null);

  const askForCameraPermission = () => {
    (async () => {
      const { status } = await BarCodeScanner.requestPermissionsAsync();
      setHasPermission(status == "granted");
    })();
  };

  //Request Camera Permission
  useEffect(() => {
    askForCameraPermission();
  }, []);

  //What happen when we scan barcode
  const handleBarCodeScanned = ({ data }) => {
    if (scanned.current === true) return;

    scanned.current = true;
    Vibration.vibrate(0.08 * 1000);
    navigation.navigate(route?.params?.returnToPage ?? "Collega", {
      data,
      qrCodeId: route?.params?.qrCodeId,
    });
    scanned.current = false;
  };

  //Check permission and return the screens

  if (hasPermission === null) {
    return (
      <View style={styles.container}>
        <Text>Richiesta di permessi fotocamera</Text>
      </View>
    );
  }

  if (hasPermission === false) {
    return (
      <View style={styles.container}>
        <Text style={{ margin: 10 }}>Nessun accesso alla fotocamera</Text>
        <Button
          title={"Consenti Fotocamera"}
          onPress={() => askForCameraPermission()}
        ></Button>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <BarCodeScanner
        onBarCodeScanned={handleBarCodeScanned}
        style={{
          height: "100%",
          width: "100%",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <View style={styles.back}>
          <Text style={styles.description}>Scannerizzare BarCode</Text>
        </View>
        <View style={{ flex: 0.5, display: "flex", flexDirection: "row" }}>
          <View style={styles.middleBack} />
          <View style={styles.barcodebox}>
            <View style={[styles.corner, styles.left]}></View>
            <View style={[styles.corner, styles.right]}></View>
            <View style={[styles.corner, styles.bottomLeft]}></View>
            <View style={[styles.corner, styles.bottomRight]}></View>
          </View>
          <View style={styles.middleBack} />
        </View>
        <View style={styles.back} />
      </BarCodeScanner>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
    height: "100%",
  },
  description: {
    fontSize: 23,
    marginTop: "10%",
    textAlign: "center",
    width: "100%",
    color: "white",
    textAlign: "center",
    zIndex: 1,
    fontWeight: "bold",
  },
  barcodebox: {
    height: "100%",
    flex: 1.2,

    borderRadius: 20,
    borderColor: "white",
  },
  maintext: {
    fontSize: 16,
    margin: 20,
  },
  buttonContainer: {
    display: "flex",
    width: "40%",
    flexDirection: "column",
    justifyContent: "space-between",
    height: "15%",
  },
  back: {
    width: "100%",
    flex: 0.3,
    opacity: 0.4,
    backgroundColor: "black",
  },
  middleBack: {
    flex: 0.2,
    opacity: 0.4,
    backgroundColor: "black",
  },
  corner: {
    position: "absolute",
    width: 30,
    height: 30,
  },
  left: {
    left: 0,
    borderLeftColor: "white",
    borderTopColor: "white",
    borderTopWidth: 6,
    borderLeftWidth: 6,
  },
  right: {
    right: 0,
    borderRightColor: "white",
    borderTopColor: "white",
    borderRightWidth: 6,
    borderTopWidth: 6,
  },
  bottomLeft: {
    bottom: 0,
    left: 0,
    borderBottomColor: "white",
    borderLeftColor: "white",
    borderBottomWidth: 6,
    borderLeftWidth: 6,
  },
  bottomRight: {
    bottom: 0,
    right: 0,
    borderBottomColor: "white",
    borderRightColor: "white",
    borderRightWidth: 6,
    borderBottomWidth: 6,
  },
});
export default QRpage;
