/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

import React from "react";
import {
  View,
  StyleSheet,
  Dimensions,
  Platform,
  StatusBar,
  TouchableOpacity,
  ScrollView,
  Text,
} from "react-native";
import { Picker } from "@react-native-picker/picker";

import Card from "../components/Card";
import {
  faLink,
  faTags,
  faShoppingBag,
  faArrowsAltV,
  faWindowRestore,
  faSignOutAlt,
  faFileCsv,
  faWrench,
  faUnlink,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { colore } from "../colore";
import { useDispatch, useSelector } from "react-redux";
import { selectStore, signOut } from "../store/authActions";
import { deleteCredentials } from "../secureStore";
import AwesomeAlert from "react-native-awesome-alerts";
import NetworkStatus from "../components/NetworkStatus";

export const { width, height } = Dimensions.get("window");

const Main = ({ navigation }) => {
  const dispatch = useDispatch();
  const { stores, selectedStore } = useSelector((rootState) => rootState.auth);

  console.log("selectedstore", selectedStore);

  const [showLogoutConfirm, setShowLogoutConfirm] = React.useState(false);
  
  const onSignOut = async () => {
    await dispatch(signOut());
    await deleteCredentials();
    navigation.navigate("SignIn");
  };

  const storeSelection = (newStore) => {
    dispatch(selectStore(newStore));
  };

  return (
    <View style={styles.screen}>
      <ScrollView style={styles.container}>
        <View style={styles.header}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              width: "100%",
              margin: "5%",
            }}
          >
            <TouchableOpacity onPress={() => setShowLogoutConfirm(true)}>
              <FontAwesomeIcon icon={faSignOutAlt} size={27} color={colore} />
            </TouchableOpacity>
            <Text style={{ color: colore, fontSize: 25, fontWeight: "bold" }}>
              TABADIGIT
            </Text>
            <NetworkStatus />
          </View>
          <View style={styles.pickerContainer}>
            <Picker
              style={styles.Picker}
              selectedValue={selectedStore}
              onValueChange={storeSelection}
            >
              {stores?.map(({ storeId, storeName }) => {
                return (
                  <Picker.Item
                    label={storeName}
                    value={storeId}
                    key={storeId}
                  />
                );
              })}
            </Picker>
          </View>
        </View>
        <View style={styles.scroll}>
          <View style={styles.cardcontainer}>
            <Card icon={faLink} title="Collega" navigationPage="Collega" />
            <Card
              icon={faWindowRestore}
              title="Collega Etichette Doppie"
              navigationPage="SearchMulticomodity"
            />
            <Card icon={faFileCsv} title="Ordine" navigationPage="Home" />
            <Card
              icon={faTags}
              title="Dettaglio Etichetta"
              navigationPage="Dettagli"
            />
            <Card icon={faUnlink} title="Scollega" navigationPage="Unbind" />
            <Card
              icon={faShoppingBag}
              title="Prodotti"
              navigationPage="Prodotti"
            />
            <Card
              icon={faArrowsAltV}
              title="Inverti ESL"
              navigationPage="Invert"
            />
            <Card icon={faWrench} title="Supporto" support />
          </View>
        </View>
      </ScrollView>
      
      <AwesomeAlert
        overlayStyle={{ height: "100%" }}
        titleStyle={{ color: "red", fontWeight: "bold" }}
        messageStyle={{ textAlign: "center" }}
        contentContainerStyle={{ borderColor: colore, borderWidth: 2 }}
        show={showLogoutConfirm}
        showProgress={false}
        title={"Conferma Logout"}
        message={"Sei sicuro di voler effettuare il logout?"}
        closeOnTouchOutside={true}
        closeOnHardwareBackPress={false}
        showConfirmButton={true}
        showCancelButton={true}
        cancelText="Annulla"
        confirmText="Conferma"
        confirmButtonColor={colore}
        onConfirmPressed={() => {
          setShowLogoutConfirm(false);
          onSignOut();
        }}
        onDismiss={() => setShowLogoutConfirm(false)}
        onCancelPressed={() => setShowLogoutConfirm(false)}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {
    flexDirection: "column",
    width: "100%",
    height: "100%",
    paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0,
    alignItems: "center",
    backgroundColor: "white",
  },
  container: {
    width: "95%",
    height: "100%",

    flexDirection: "column",
    backgroundColor: "white",
  },
  header: {
    width: "100%",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "space-between",
  },
  cardcontainer: {
    marginTop: "7%",
    flexDirection: "row",
    width: "100%",
    flexWrap: "wrap",
    alignItems: "center",
  },
  scroll: {
    width: "100%",
  },
  cardColumn: {
    flexDirection: "row",
  },
  Picker: {
    width: "100%",
    color: colore,
  },
  pickerContainer: {
    width: "95%",
    borderRadius: 15,
    borderWidth: 2,
    borderColor: colore,
  },
});
export default Main;
