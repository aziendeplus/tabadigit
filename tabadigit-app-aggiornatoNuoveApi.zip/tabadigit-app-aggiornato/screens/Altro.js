import { NavigationContainer } from '@react-navigation/native';
import React from 'react'
import { StyleSheet, View, TouchableOpacity,Button,Text } from 'react-native'


const Altro = ({navigation}) => {
    return (
        <View style={styles.main}>
            <TouchableOpacity  onPress={navigation.navigate("qualcosa")}><Text>premi</Text></TouchableOpacity>
        </View>
    )
}

const styles = StyleSheet.create({
    main: {
       marginTop:200
    }
});
export default Altro