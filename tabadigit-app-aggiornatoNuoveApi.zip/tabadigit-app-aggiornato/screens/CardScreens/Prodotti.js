import React, { useState, useEffect, useContext } from "react";
import {
  StyleSheet,
  View,
  Text,
  StatusBar,
  Platform,
  TouchableOpacity,
  FlatList,
} from "react-native";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { faSearch } from "@fortawesome/free-solid-svg-icons";
import { TextInput } from "react-native-paper";
import { colore } from "../../colore";
import Prodotto from "../../components/Prodotto";
import { apiWithRetry, getProducts, getProductByAms } from "../../api";
import { useDispatch, useSelector } from "react-redux";
import { signIn } from "../../store/authActions";

const Prodotti = ({ navigation }) => {
  const dispatch = useDispatch();
  const { token, selectedStore } = useSelector((rootState) => rootState.auth);
  const [products, setProducts] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [loading, setLoading] = React.useState(true);
  const [refresh, setRefresh] = React.useState(0);
  const [text, setText] = React.useState("");
  //i parametri della barra di ricerca
  const [parameters, setParameters] = React.useState({
    barcode: null,
    nome: null,
  });

  const handleEndReached = React.useCallback(() => {
    console.log("handle\n");
    setPage((page) => page + 1);
  }, []);

  const handleRefresh = () => {
    setRefresh(refresh + 1);
    setProducts([]);
    setPage(0);
  };

  async function getProds() {
    setLoading(true);
    let amsProduct
    try {
      
      if (page === 0) {
        const responseAms = await apiWithRetry(
          () =>
          getProductByAms(
              token,
              selectedStore,
              parameters.barcode || parameters.nome
            ),
          dispatch
        );

        if (responseAms?.data?.list?.length) {
          const amsItem = responseAms.data.list[0]
          if (amsItem) {
            amsProduct = {
              id: amsItem.id,
              Nome: amsItem.itemTitle,
              Prezzo: amsItem.price,
              Barcode: amsItem.barCode,
              Tipologia: amsItem.type,
              CodiceProdotto: amsItem.productCode,
              Categoria: amsItem.attrCategory,
              attrName: amsItem.attrName,
              custFeature1: amsItem.custFeature1,
              custFeature2: amsItem.custFeature2,
              custFeature3: amsItem.custFeature3,
              custFeature4: amsItem.custFeature4,
              Unità: amsItem.unit,
            }
          }
        }
      }


      let response = await apiWithRetry(
        () =>
          getProducts(
            token,
            page,
            selectedStore,
            parameters.barcode,
            parameters.nome
          ),
        dispatch
      );

      let arr =
        response.data?.list?.map((item) => ({
          id: item.id,
          Nome: item.itemTitle,
          Prezzo: item.price,
          Barcode: item.barCode,
          Tipologia: item.type,
          CodiceProdotto: item.productCode,
          Categoria: item.attrCategory,
          attrName: item.attrName,
          custFeature1: item.custFeature1,
          custFeature2: item.custFeature2,
          custFeature3: item.custFeature3,
          custFeature4: item.custFeature4,
          Unità: item.unit,
        })) || [];

        if (page === 0 && amsProduct) {
          setProducts([amsProduct, ...arr]);
        } else {
          setProducts([...products, ...arr]);
        }
      setLoading(false);
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    getProds();
  }, [page, refresh]);

  const handleSearch = () => {
    if (isNaN(text)) setParameters({ barcode: null, nome: text });
    else setParameters({ barcode: text, nome: null });

    handleRefresh();
  };

  return (
    <View style={styles.main}>
      <View style={styles.filterContainer}>
        <TextInput
          label="ID/Nome/Barcode/AMS"
          value={text}
          onChangeText={(text) => setText(text)}
          placeholder="Filtra per Nome/Barcode del prodotto"
          style={styles.textFilter}
          mode="outlined"
          theme={{ colors: { primary: colore } }}
          outlineColor="grey"
          onEndEditing={handleSearch}
        />
        <TouchableOpacity onPress={handleSearch}>
          <FontAwesomeIcon icon={faSearch} size={25} />
        </TouchableOpacity>
      </View>
      <View style={styles.contentContainer}>
        <FlatList
          refreshing={loading}
          style={styles.list}
          data={products}
          progressViewOffset={10}
          //ListFooterComponent={loading ? <FlatlistFooter /> : null}
          ListFooterComponentStyle={{ flex: 1, justifyContent: "flex-end" }}
          contentContainerStyle={{ flexGrow: 1 }}
          onEndReachedThreshold={0.01}
          onEndReached={handleEndReached}
          renderItem={({ item }) => (
            <View style={styles.content}>
              <Prodotto data={item} navigation={navigation} />
            </View>
          )}
          onRefresh={handleRefresh}
          keyExtractor={(item) => item.id}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  main: {
    width: "100%",
    flexDirection: "column",
    flex: 1,
    backgroundColor: "white",
  },
  filterContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    width: "100%",
    paddingHorizontal: 10,
    marginTop: 10,
    minHeight: 100,
  },
  textFilter: {
    flex: 0.9,
  },
  contentContainer: {
    width: "100%",
    flex: 1,
    borderTopWidth: 2,
  },
  list: {
    height: "100%",
  },
  content: {},
});
export default Prodotti;
