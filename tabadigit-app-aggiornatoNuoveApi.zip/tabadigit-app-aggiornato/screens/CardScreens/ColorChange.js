import React from "react";
import { View } from "react-native";
import { ColorPicker } from "react-native-color-picker";
import { setColore } from "../../colore";
import { colore } from "../../colore";

const ColorChange = () => {
  return (
    <View
      style={{
        width: "100%",
        height: "100%",
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "white",
      }}
    >
      <ColorPicker
        style={{ width: "80%", height: "80%" }}
        onColorSelected={(color) => setColore(color)}
        defaultColor={colore}
      />
    </View>
  );
};

export default ColorChange;
