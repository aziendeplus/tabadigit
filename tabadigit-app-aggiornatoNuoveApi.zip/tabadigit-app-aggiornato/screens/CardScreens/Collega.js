import React, { useRef, useEffect, useCallback } from "react";
import {
  StyleSheet,
  View,
  Text,
  Platform,
  StatusBar,
  TouchableOpacity,
} from "react-native";
import { colore } from "../../colore";
import { apiWithRetry, bindItems, getItemByStoreBarcode } from "../../api";
import { useDispatch, useSelector } from "react-redux";
import AwesomeAlert from "react-native-awesome-alerts";
import AwesomeButton from "react-native-really-awesome-button";
import InputCode from "../../components/InputCode";
import * as MailComposer from "expo-mail-composer";
import * as Progress from "react-native-progress";
import { usePrevious } from "../../utils";

const Collega = () => {
  const dispatch = useDispatch();
  const barcodeRef = useRef();
  const eslRef = useRef();
  const { token, selectedStore } = useSelector((rootState) => rootState.auth);
  const [tabacchiCode, setTabacchiCode] = React.useState("");
  const [eslCode, setESLCode] = React.useState("");
  const [noProductAlert, setNoProductAlert] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  const prevTabacchi = usePrevious(tabacchiCode);
  const prevEsl = usePrevious(eslCode);

  const [Alt, setAlt] = React.useState({
    showAlert: false,
    title: "",
    message: "",
  });

  useEffect(() => {
    if (barcodeRef) {
      setTimeout(() => barcodeRef.current.focus(), 500);
    }
  }, [barcodeRef]);

  async function bind() {
    setLoading(true);

    if (eslCode && tabacchiCode) {
      try {
        const product = await apiWithRetry(
          () => getItemByStoreBarcode(token, selectedStore, tabacchiCode),
          dispatch
        );

        if (!product.data) {
          setLoading(false);
          return setNoProductAlert(true);
        }

        const response = await apiWithRetry(
          () => bindItems(token, selectedStore, eslCode, tabacchiCode),
          dispatch
        );

        if (response.success) {
          setAlt({
            showAlert: true,
            title: "CONNESSO",
            message: "Dispositivi associati con successo",
          });
          setTabacchiCode("");
          setESLCode("");
        } else if (response.code === 15069) {
          setAlt({
            showAlert: true,
            title: "ATTENZIONE",
            message: "L'etichetta fornita non esiste per questo negozio!",
          });
        } else if (response.code === 13026) {
          setAlt({
            showAlert: true,
            title: "ATTENZIONE",
            message: "Dispositivi già connessi",
          });
        } else {
          setAlt({
            showAlert: true,
            title: "ATTENZIONE",
            message:
              "Errore nell'associazione degli oggetti,controlla che gli oggetti inseriti siano corretti o che siano disponibili nel catalogo.",
          });
        }
      } catch (err) {
        console.error(err);

        setAlt({
          showAlert: true,
          title: "ATTENZIONE",
          message: "Errore nell'associazione degli oggetti,",
        });
      }
    } else {
      setAlt({
        showAlert: true,
        title: "ERRORE",
        message: `Inserisci prima i codici di prodotto e etichetta ${tabacchiCode} - ${eslCode}`,
      });
    }

    setLoading(false);
  }

  useEffect(() => {
    if (tabacchiCode.length - prevTabacchi?.length > 5) {
      setTimeout(() => eslRef.current.focus(), 500);
    }
  }, [tabacchiCode]);

  useEffect(() => {
    if (eslCode.length - prevEsl?.length > 5) bind();
  }, [eslCode]);

  return (
    <View style={styles.main}>
      <View style={styles.inputContainer}>
        <InputCode
          ref={barcodeRef}
          id={1}
          value={tabacchiCode}
          setValue={setTabacchiCode}
          label="Barcode Prodotto"
          withNFC={false}
        />

        <InputCode
          ref={eslRef}
          id={2}
          value={eslCode}
          setValue={setESLCode}
          label="Codice ESL"
        />
      </View>

      <View style={styles.tableContainer}>
        <View style={styles.tableInner}>
          <View style={{ width: "90%" }}>
            <AwesomeButton
              backgroundDarker="#e8e8e8"
              width="100%"
              type="primary"
              backgroundColor={colore}
              borderRadius={6}
              height={60}
              raiseLevel={5}
              progress
              onPress={(next) => {
                bind();
                next();
              }}
            >
              {loading ? (
                <Progress.Circle
                  size={30}
                  borderWidth={5}
                  indeterminate={true}
                  color="white"
                />
              ) : (
                <Text
                  style={{ fontSize: 18, fontWeight: "bold", color: "white" }}
                >
                  ASSOCIA
                </Text>
              )}
            </AwesomeButton>
          </View>
        </View>
      </View>

      <View style={styles.alert}>
        <AwesomeAlert
          overlayStyle={{ height: "100%" }}
          titleStyle={{ color: "red", fontWeight: "bold" }}
          messageStyle={{ textAlign: "center" }}
          contentContainerStyle={{ borderColor: colore, borderWidth: 2 }}
          show={Alt.showAlert}
          showProgress={Alt.showAlert}
          title={Alt.title}
          message={Alt.message}
          closeOnTouchOutside={true}
          closeOnHardwareBackPress={false}
          showConfirmButton={true}
          confirmText="OK"
          confirmButtonColor={colore}
          onConfirmPressed={() => setAlt({ ...Alt, showAlert: false })}
          onDismiss={() => setAlt({ ...Alt, showAlert: false })}
          showProgress={true}
        />
      </View>

      <AwesomeAlert
        overlayStyle={{ height: "100%" }}
        titleStyle={{ color: "red", fontWeight: "bold" }}
        messageStyle={{ textAlign: "center" }}
        contentContainerStyle={{ borderColor: colore, borderWidth: 2 }}
        show={noProductAlert}
        title={"Prodotto non trovato"}
        message={
          "Sei sicuro che il codice sia di un prodotto valido? Per favore contattaci all'indirizzo email supporto@tabadigit.it"
        }
        closeOnTouchOutside={true}
        closeOnHardwareBackPress={false}
        showConfirmButton={true}
        showCancelButton={true}
        cancelText="No"
        confirmText="Okay"
        confirmButtonColor={colore}
        onConfirmPressed={() => setNoProductAlert(false)}
        onDismiss={() => setNoProductAlert(false)}
        onCancelPressed={() => setNoProductAlert(false)}
        showProgress={true}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  main: {
    backgroundColor: "white",
    width: "100%",
    height: "100%",
  },
  tableContainer: {
    marginVertical: 40,
    flex: 1,
    minHeight: 400,
  },
  tableInner: {
    alignItems: "center",
  },
  alert: {},
  spinnerTextStyle: {
    color: "#FFF",
  },
  inputContainer: {
    marginTop: "10%",
    flexDirection: "column",
    height: "25%",
    justifyContent: "space-between",
    paddingHorizontal: 10,
  },
});

TouchableOpacity.defaultProps = { activeOpacity: 0.5 };
export default Collega;
