import React, { useState } from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import TextInputDetail from "../components/TextInputDetail";
import AwesomeButton from "react-native-really-awesome-button";
import { colore } from "../colore";
import AwesomeAlert from "react-native-awesome-alerts";
import { useSelector } from "react-redux";
import InputCode from "../components/InputCode";
import { getEmptyItemFields } from "./CreaProdotto";
import { createItem, login, logout } from "../api";
import { encryptPassword } from "../store/authActions";
import { getCredentials } from "../secureStore";

const DuplicaProdotto = ({ route }) => {
  const { token } = useSelector((rootState) => rootState.auth);
  const [product, setProduct] = useState(route.params.data);
  const [alert, setAlert] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selectedBarcode, setSelectedBarcode] = useState();

  async function onSubmit() {
    setLoading(true);
    try {
      let adminToken;
      const { username } = await getCredentials();

      if (username === "eslagent001") {
        adminToken = token;
      } else {
        var encryptedPassword = await encryptPassword("eslagent001");

        const loginResponse = await login(username, encryptedPassword);

        adminToken = loginResponse?.data?.token;
      }

      const { id, isSpecs, itemExt, ...productDataToCopy } = product;
      const response = await createItem(token, {
        ...getEmptyItemFields(),
        ...productDataToCopy,
        barCode: selectedBarcode,
      });

      console.log(response);

      if (!response.success) {
        setAlert(true);
      }
    } catch (error) {
      console.error(error);
      setAlert(true);
    }

    setLoading(false);
  }

  return (
    <View style={styles.main}>
      <AwesomeAlert
        overlayStyle={{ height: "100%" }}
        show={alert}
        showProgress={alert}
        title="ERRORE"
        message="Errore durante la creazione del prodotto"
        closeOnTouchOutside={true}
        closeOnHardwareBackPress={false}
        showConfirmButton={true}
        confirmText="OK"
        confirmButtonColor={colore}
        onConfirmPressed={() => setAlert(false)}
        onDismiss={() => setAlert(false)}
      />
      {product && (
        <>
          <ScrollView style={{ width: "100%" }}>
            <TextInputDetail
              title="Nome"
              value={product.itemTitle}
              unchangeable={true}
              editable={false}
            />
            <TextInputDetail
              title="Prezzo"
              value={product.price.toString()}
              editable={false}
            />
            <TextInputDetail
              title="Codice AMS"
              value={product.productCode}
              unchangeable={true}
              editable={false}
            />
            <View style={styles.barcode}>
              <Text style={styles.textBarCode}>Barcode</Text>
              <InputCode
                id={14}
                value={selectedBarcode}
                setValue={setSelectedBarcode}
                label=""
              />
            </View>
          </ScrollView>
          <View
            style={{ width: "100%", marginVertical: 20, alignItems: "center" }}
          >
            <View style={{ width: "60%" }}>
              <AwesomeButton
                backgroundDarker="#e8e8e8"
                width="100%"
                type="primary"
                backgroundColor={colore}
                borderRadius={6}
                height={60}
                raiseLevel={5}
                progress={true}
                onPress={(next) => {
                  onSubmit();
                  next();
                }}
              >
                <Text style={styles.buttonText}>Aggiungi</Text>
              </AwesomeButton>
            </View>
          </View>
        </>
      )}
    </View>
  );
};
const styles = StyleSheet.create({
  main: {
    width: "100%",
    height: "100%",
    backgroundColor: "white",
  },
  buttonText: { fontSize: 20, fontWeight: "bold", color: "white" },
  barcode: {
    marginTop: 20,
    marginLeft: 10,
    flexDirection: "row",
    alignContent: "center",
    alignItems: "center",
  },
});
export default DuplicaProdotto;
