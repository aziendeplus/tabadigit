import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
  KeyboardAvoidingView,
} from "react-native";
import { useState, useEffect } from "react";
import Product from "../components/product";
import { apiWithRetry, getProductByBarCode } from "../api";
import { useDispatch, useSelector } from "react-redux";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import { faCheck } from "@fortawesome/free-solid-svg-icons";
import { faHome } from "@fortawesome/free-solid-svg-icons";

const ProductDetails = ({ navigation, route }) => {
  const dispatch = useDispatch();
  const { token } = useSelector((rootState) => rootState.auth);

  const [loading, setLoading] = useState(true);
  const [item, setItem] = useState();
  const [amount, setAmount] = useState();

  useEffect(() => {
    async function setProduct(idNavigation) {
      const productResponse = await apiWithRetry(
        () => getProductByBarCode(token, idNavigation),
        dispatch
      );

      setItem(productResponse?.data?.list[0]);
      setLoading(false);
    }

    const itemNavigation = route.params.item;
    const idNavigation = route.params.id;
    if (idNavigation) {
      setProduct(idNavigation);
    } else if (itemNavigation) {
      setItem(itemNavigation);
      setAmount(itemNavigation.amount);
      setLoading(false);
    }
  }, [navigation]);

  const annulla = () => {
    navigation.navigate("Home");
  };

  const done = () => {
    if (!isNaN(amount) && amount != "" && amount != undefined) {
      navigation.navigate("Home", {
        item: { ...item, amount },
      });
    }
  };

  return (
    <KeyboardAvoidingView style={styles.container}>
      <View style={styles.productContainer}>
        {loading ? (
          <ActivityIndicator size="large" />
        ) : item === undefined ? (
          <Text>Nessun prodotto corrispondente</Text>
        ) : (
          <Product item={item} amount={amount} setAmount={setAmount} />
        )}
      </View>
      <View style={styles.buttonContainer}>
        <TouchableOpacity onPress={annulla} style={styles.button}>
          <FontAwesomeIcon icon={faHome} size={27} style={{ color: "white" }} />
        </TouchableOpacity>
        <TouchableOpacity onPress={done} style={styles.button}>
          <FontAwesomeIcon
            icon={faCheck}
            size={27}
            style={{ color: "white" }}
          />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    display: "flex",
    flexDirection: "column",
    width: "100%",
    height: "100%",
    alignItems: "center",
    backgroundColor: "white",
  },
  productContainer: {
    width: "100%",
    flex: 0.9,
  },
  button: {
    flex: 0.4,
    display: "flex",
    alignItems: "center",
    backgroundColor: "#379392",
    borderRadius: 10,
    height: 40,
    justifyContent: "center",
    shadowColor: "#000",

    shadowOffset: {
      width: 0,
      height: 11,
    },
    shadowOpacity: 0.9,
    shadowRadius: 15.19,

    elevation: 3,
  },
  buttonText: {
    fontSize: 14,
    color: "#fff",
    fontWeight: "bold",
    alignSelf: "center",
    textTransform: "uppercase",
  },
  buttonContainer: {
    width: "100%",
    position: "absolute",
    bottom: 0,
    flexDirection: "row",
    justifyContent: "space-around",
    backgroundColor: "white",
    paddingBottom: 10,
  },
});

TouchableOpacity.defaultProps = { activeOpacity: 0.8 };
export default ProductDetails;
