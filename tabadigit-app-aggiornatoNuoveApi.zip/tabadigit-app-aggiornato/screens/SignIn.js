import React, { useContext } from "react";
import { StyleSheet, Text, View } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { colore } from "../colore";
import AwesomeButton from "react-native-really-awesome-button";
import AwesomeAlert from "react-native-awesome-alerts";
import { TextInput } from "react-native-paper";
import { flushError, signIn } from "../store/authActions";

const SignIn = ({ navigation }) => {
  const dispatch = useDispatch();
  const { token, error } = useSelector((rootState) => rootState.auth);
  const [username, setUsername] = React.useState();
  const [password, setPassword] = React.useState();
  const [disable, setDisable] = React.useState(false);

  async function OnPressSignIn() {
    setDisable(true);
    dispatch(signIn({ username, password }));
    setDisable(false);
  }

  if (token) {
    navigation.navigate("Main");
  }

  function removeError() {
    dispatch(flushError());
  }

  return (
    <View style={styles.safeArea}>
      <View style={styles.sfondo}></View>
      <View style={styles.formContainer}>
        <Text style={{ color: colore, fontSize: 25, fontWeight: "bold", textAlign: 'center' }}>
          BENVENUTO in {'\n'}
          <Text style={{ color: colore, fontSize: 25, fontWeight: "bold" }}>
            TABADIGIT
          </Text>
        </Text>
        <TextInput
          label="Username"
          theme={{ colors: { primary: colore } }}
          style={styles.textInput}
          value={username}
          onChangeText={setUsername}
          disabled={disable}
        />

        <TextInput
          label="Password"
          theme={{ colors: { primary: colore } }}
          style={styles.textInput}
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          disabled={disable}
        />
        <View style={{ width: "80%", flexDirection: "row" }}>
          <AwesomeButton
            backgroundDarker="#e8e8e8"
            type="primary"
            backgroundColor={colore}
            borderRadius={6}
            height={60}
            raiseLevel={3}
            progress
            progressLoadingTime={2000}
            onPress={(next) => {
              OnPressSignIn();
              next();
            }}
            width="100%"
          >
            {/*loading ? (
              <Progress.Circle
                size={30}
                borderWidth={5}
                indeterminate={true}
                color="white"
              />
            ) : (
              <Text
                style={{ fontSize: 19, fontWeight: "bold", color: "white" }}
              >
                Accedi
              </Text>
            )*/}
            <Text style={{ fontSize: 19, fontWeight: "bold", color: "white" }}>
              ACCEDI
            </Text>
          </AwesomeButton>

          {error && (
            <AwesomeAlert
              overlayStyle={{ height: "100%" }}
              show={error}
              title={"Errore"}
              message={error}
              closeOnTouchOutside={true}
              closeOnHardwareBackPress={false}
              showConfirmButton={true}
              confirmText="OK"
              confirmButtonColor={colore}
              onConfirmPressed={removeError}
              onDismiss={removeError}
              showProgress={true}
            />
          )}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    paddingTop: Platform.OS === "android" ? 0 : 10,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#ffffff",
    minHeight: "100%",
  },
  formContainer: {
    flexDirection: "column",
    width: "80%",
    height: "70%",
    backgroundColor: "white",
    elevation: 8,
    alignItems: "center",
    justifyContent: "space-around",
    borderRadius: 12,
    minHeight: 450,
  },
  sfondo: {
    width: "100%",
    height: "100%",
    backgroundColor: colore,
    zIndex: -1,
    position: "absolute",
  },
  check: {},
  textInput: {
    width: "80%",
    borderBottomColor: "#A5a5a8",
    height: 60,
    backgroundColor: "white",
    fontSize: 20,
  },
});

export default SignIn;
