/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

import React, { useEffect, useRef } from "react";
import {
  View,
  ScrollView,
  StyleSheet,
  Text,
  FlatList,
  BackHandler,
} from "react-native";
import { Buffer as NodeBuffer } from "buffer";
import * as FileSystem from "expo-file-system";
import * as Sharing from "expo-sharing";
import InputCode from "../components/InputCode";
import AwesomeButton from "react-native-really-awesome-button";
import { colore } from "../colore";
import { apiWithRetry, getProductByBarCode } from "../api";
import { useDispatch, useSelector } from "react-redux";
import AwesomeAlert from "react-native-awesome-alerts";
import ProductOrder from "../components/ProductOrder";
import Loading from "../components/Loading";
import ExcelJS from "exceljs";
import { usePrevious } from "../utils";
import { getData, storeData } from "../storage";

const ORDER_KEY = "ordine";

const Home = ({ route }) => {
  const dispatch = useDispatch();
  const { token, selectedStore } = useSelector((rootState) => rootState.auth);

  const [cigs, setCigs] = React.useState([]);
  const initialized = useRef(false);
  const [barcode, setBarcode] = React.useState("");
  const [Alt, setShowAlt] = React.useState({
    show: false,
    title: "",
    message: "",
  });
  const [loading, setLoading] = React.useState(false);
  const [noProductAlert, setNoProductAlert] = React.useState(false);
  const barcodeRef = React.useRef();
  const [exportDisabled, setExportDisabled] = React.useState(false);

  const prevBarcode = usePrevious(barcode);

  useEffect(() => {
    if (barcodeRef?.current) barcodeRef.current.focus();
  }, [barcodeRef]);

  const handleRemove = (barcode) => {
    let cigCopy = [...cigs];
    setCigs(cigCopy.filter((prod) => prod.Barcode !== barcode));
  };

  const esporta = async () => {
    try {
      if (cigs.length === 0) {
        setShowAlt({
          show: true,
          title: "Attenzione",
          message: "Non ci sono prodotti nell'ordine. Aggiungi almeno un prodotto prima di esportare.",
        });
        return;
      }
      
      // Verifica che tutte le quantità rispettino l'unità minima
      const invalidItems = cigs.filter(item => item.quantita < item.unitaminima);
      if (invalidItems.length > 0) {
        setShowAlt({
          show: true,
          title: "Quantità non valide",
          message: `Alcuni prodotti hanno quantità inferiori all'unità minima. Correggi le quantità prima di esportare.`,
        });
        return;
      }
      
      const shareableExcelUri = await generateExcel();
      await Sharing.shareAsync(shareableExcelUri, {
        mimeType:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        dialogTitle: "Condividi Ordine", // Android and Web
        UTI: "com.microsoft.excel.xls", // iOS
      });
      
      // Mostra conferma di successo
      setShowAlt({
        show: true,
        title: "Esportazione completata",
        message: "L'ordine è stato esportato con successo.",
      });
    } catch (error) {
      setShowAlt({
        show: true,
        title: "Errore durante la costruzione del file excel",
        message: error.message || "Si è verificato un errore durante l'esportazione",
      });
      console.error("Error", error);
    }
  };

  function generateExcel() {
    let jsonData = [];
    cigs.forEach((item, index) => {
      console.log(item);
      jsonData[index] = {
        quantita: item.quantita,
        productCode: item.productCode,
        nome: item.Nome,
        prezzo: item.Prezzo
      };
    });

    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const fileName = `Ordine_${year}${month}${day}_${hours}${minutes}.xls`;
    const fileUri = FileSystem.cacheDirectory + fileName;

    return new Promise((resolve, reject) => {
      try {
        const workbook = new ExcelJS.Workbook();
        workbook.creator = "Tabadigit";
        workbook.created = now;
        workbook.modified = now;
        workbook.lastPrinted = now;
        
        // Aggiungi informazioni di proprietà
        workbook.properties.company = "M.G.Informatica di Mandalà Giuseppe";
        workbook.properties.title = "Ordine Tabadigit";
        workbook.properties.subject = "Ordine prodotti";
        
        // Add a sheet to work on
        const worksheet = workbook.addWorksheet("Ordine", {});
        worksheet.columns = [
          { header: "Codice AAMS", key: "productCode", width: 15 },
          { header: "Nome Prodotto", key: "nome", width: 40 },
          { header: "Quantità", key: "quantita", width: 15 },
          { header: "Prezzo", key: "prezzo", width: 15 }
        ];

        // Stile intestazione
        worksheet.getRow(1).font = { bold: true, size: 12 };
        worksheet.getRow(1).fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFE0E0E0' }
        };

        // Aggiungi i prodotti
        for (let product of jsonData) {
          worksheet.addRow(product);
        }

        // Aggiungi totale
        const totalRow = worksheet.rowCount + 2;
        worksheet.getCell(`A${totalRow}`).value = "TOTALE PRODOTTI:";
        worksheet.getCell(`A${totalRow}`).font = { bold: true };
        worksheet.getCell(`C${totalRow}`).value = { formula: `SUM(C2:C${worksheet.rowCount})` };
        worksheet.getCell(`C${totalRow}`).font = { bold: true };

        // Aggiungi data e ora
        worksheet.getCell(`A${totalRow+2}`).value = `Ordine generato il: ${day}/${month}/${year} alle ${hours}:${minutes}`;
        worksheet.getCell(`A${totalRow+3}`).value = "www.tabadigit.it";
        worksheet.getCell(`A${totalRow+3}`).font = { italic: true, color: { argb: '0000FF' } };

        // Write to file
        workbook.xlsx.writeBuffer().then((buffer) => {
          // Do this to use base64 encoding
          const nodeBuffer = NodeBuffer.from(buffer);
          const bufferStr = nodeBuffer.toString("base64");
          FileSystem.writeAsStringAsync(fileUri, bufferStr, {
            encoding: FileSystem.EncodingType.Base64,
          }).then(() => {
            resolve(fileUri);
          }).catch(err => {
            reject(err);
          });
        }).catch(err => {
          reject(err);
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  const handleConfirm = async () => {
    if (!barcode || barcode.trim() === "") {
      setShowAlt({
        show: true,
        title: "Attenzione",
        message: "Inserisci un codice barcode valido",
      });
      return;
    }
    
    const alreadyAdded = !!cigs.find((item) => item.Barcode === barcode);

    if (alreadyAdded)
      setShowAlt({
        show: true,
        title: "ERRORE",
        message: "Prodotto già selezionato",
      });
    else {
      setLoading(true);
      try {
        const response = await apiWithRetry(
          () => getProductByBarCode(token, selectedStore, barcode),
          dispatch
        );

        let item = response?.data?.list[0];

        if (item) {
          const unitaMinimaString = item.custFeature3.replace(",", ".");
          const unitaMinimaFloat = parseFloat(unitaMinimaString) || 1; // Default a 1 se non valido

          let cig = {
            id: item.id,
            Nome: item.itemTitle,
            Prezzo: item.price,
            Barcode: item.barCode,
            attrName: item.attrName,
            quantita: unitaMinimaFloat,
            productCode: item.productCode,
            unitaminima: unitaMinimaFloat,
          };

          setCigs([...cigs, cig]);
          setBarcode("");
          if (barcodeRef?.current) barcodeRef.current.focus();
          
          // Mostra conferma di aggiunta prodotto
          setShowAlt({
            show: true,
            title: "Prodotto aggiunto",
            message: `${item.itemTitle} aggiunto all'ordine con quantità ${unitaMinimaFloat}`,
          });
        } else {
          setNoProductAlert(true);
        }
      } catch (error) {
        console.error(error);
        setShowAlt({
          show: true,
          title: "NET ERROR",
          message: error.message || "Errore durante la ricerca del prodotto",
        });
      } finally {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    if (route?.params) {
      console.log(JSON.stringify(route?.params));
    }
  }, [route?.params]);

  useEffect(() => {
    if (!initialized.current) {
      initialized.current = true;

      getData(ORDER_KEY).then((firstCigs) => {
        if (Array.isArray(firstCigs)) setCigs(firstCigs);
      });
    } else {
      storeData(ORDER_KEY, cigs);
    }
  }, [cigs]);

  return (
    <ScrollView contentContainerStyle={styles.mainContainer}>
      {loading && <Loading />}

      <View style={{ width: "100%", flexDirection: "row", height: 60 }}>
        <View style={{ width: "100%" }}>
          <InputCode
            id="1"
            value={barcode}
            setValue={setBarcode}
            label="Barcode"
            ref={barcodeRef}
          />
        </View>
      </View>
      <View style={styles.importButtonsLayout}>
        <AwesomeButton
          style={{ marginTop: 20, width: "40%" }}
          backgroundDarker="#e8e8e8"
          type="primary"
          width="100%"
          backgroundColor={colore}
          borderRadius={6}
          height={60}
          raiseLevel={4}
          disabled={barcode == "" || barcode === "undefined"}
          progress
          onPress={(next) => {
            handleConfirm();
            next();
          }}
        >
          <Text style={styles.buttonText}>Inserisci</Text>
        </AwesomeButton>
      </View>
      <View style={styles.list}>
        <FlatList
          style={{ height: "100%" }}
          data={cigs}
          progressViewOffset={10}
          //ListFooterComponent={loading ? <FlatlistFooter /> : null}
          //ListFooterComponentStyle={{ flex: 1, justifyContent: 'flex-end' }}
          contentContainerStyle={{ flexGrow: 1 }}
          renderItem={({ item }) => (
            <ProductOrder
              item={item}
              handleRemove={handleRemove}
              onChangeText={(value) => {
                console.log("New Value", value);
                item.quantita = value;

                if (item.unitaminima > item.quantita) setExportDisabled(true);
                else setExportDisabled(false);
              }}
            />
          )}
          keyExtractor={(item) => item.id}
        />
      </View>
      <View style={styles.buttonContainer}>
        <AwesomeButton
          backgroundDarker="#e8e8e8"
          width="100%"
          type="primary"
          backgroundColor={exportDisabled ? "#d4d4d4" : colore}
          borderRadius={6}
          height={60}
          raiseLevel={5}
          onPress={esporta}
          disabled={exportDisabled}
        >
          <Text style={styles.buttonText}>ESPORTA</Text>
        </AwesomeButton>
      </View>
      <View>
        <AwesomeAlert
          overlayStyle={{ height: "100%" }}
          titleStyle={{ color: "red", fontWeight: "bold" }}
          messageStyle={{ textAlign: "center" }}
          contentContainerStyle={{ borderColor: colore, borderWidth: 2 }}
          show={Alt.show}
          showProgress={Alt.show}
          title={Alt.title}
          message={Alt.message}
          closeOnTouchOutside={true}
          closeOnHardwareBackPress={false}
          showConfirmButton={true}
          confirmText="OK"
          confirmButtonColor={colore}
          onConfirmPressed={() => setShowAlt({ ...Alt, show: false })}
          onDismiss={() => setShowAlt({ ...Alt, show: false })}
        />
      </View>

      <AwesomeAlert
        overlayStyle={{ height: "100%" }}
        titleStyle={{ color: "red", fontWeight: "bold" }}
        messageStyle={{ textAlign: "center" }}
        contentContainerStyle={{ borderColor: colore, borderWidth: 2 }}
        show={noProductAlert}
        title={"Prodotto non trovato"}
        message={
          "Sei sicuro che il codice sia di un prodotto valido? Per favore contattaci all'indirizzo email supporto@tabadigit.it"
        }
        closeOnTouchOutside={true}
        closeOnHardwareBackPress={false}
        showConfirmButton={true}
        showCancelButton={true}
        cancelText="No"
        confirmText="Okay"
        confirmButtonColor={colore}
        onConfirmPressed={() => setNoProductAlert(false)}
        onDismiss={() => setNoProductAlert(false)}
        onCancelPressed={() => setNoProductAlert(false)}
        showProgress={true}
      />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  list: {
    width: "100%",
    flex: 1,
  },
  Itemscontainer: {
    display: "flex",
    flexDirection: "column",
    flex: 1,
    alignItems: "center",
  },
  mainContainer: {
    paddingTop: 4,
    width: "100%",
    flexDirection: "column",
    backgroundColor: "white",
    flex: 1,
  },
  cigContainer: {
    width: "100%",
    alignItems: "center",
  },
  buttonContainer: {
    width: "100%",
    height: 50,
  },
  buttonText: { fontWeight: "bold", color: "white", fontSize: 18 },
  importButtonsLayout: {
    width: "100%",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-around",
    marginBottom: 20,
  },
});

export default Home;
