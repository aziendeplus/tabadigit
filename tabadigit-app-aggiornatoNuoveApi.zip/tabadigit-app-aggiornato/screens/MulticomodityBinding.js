import React, { useEffect, useRef } from "react";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";
import { colore } from "../colore";
import { apiWithRetry, bindMulti } from "../api";
import { useDispatch, useSelector } from "react-redux";
import AwesomeAlert from "react-native-awesome-alerts";
import AwesomeButton from "react-native-really-awesome-button";
import InputCode from "../components/InputCode";
import * as Progress from "react-native-progress";
import { usePrevious } from "../utils";

const MulticomodityBinding = ({ route }) => {
  const dispatch = useDispatch();
  const { token, selectedStore } = useSelector((rootState) => rootState.auth);
  const [template, setTemplate] = React.useState();
  const [tabacchiCode1, setTabacchiCode1] = React.useState("");
  const [tabacchiCode2, setTabacchiCode2] = React.useState("");
  const [eslCode, setESLCode] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const barcode1Ref = useRef();
  const barcode2Ref = useRef();
  const eslRef = useRef();

  const prevCode1 = usePrevious(tabacchiCode1);
  const prevCode2 = usePrevious(tabacchiCode2);
  const prevEsl = usePrevious(eslCode);

  useEffect(() => {
    if (barcode1Ref?.current) barcode1Ref.current.focus();
  }, [barcode1Ref]);

  const [Alt, setAlt] = React.useState({
    showAlert: false,
    title: "",
    message: "",
  });

  useEffect(() => {
    if (route?.params?.template) setTemplate(route?.params?.template);
  }, [route?.params]);

  async function bind() {
    setLoading(true);
    if (tabacchiCode1 && tabacchiCode2 && eslCode) {
      try {
        const response = await apiWithRetry(
          () =>
            bindMulti(
              token,
              selectedStore,
              eslCode,
              tabacchiCode1,
              tabacchiCode2,
              template.id
            ),
          dispatch
        );

        console.log(response)

        if (response.success) {
          setAlt({
            showAlert: true,
            title: "CONNESSO",
            message: "Dispositivi associati con successo",
          });
          setTabacchiCode2("");
          setTabacchiCode1("");
          setESLCode("");
        } else if (response.code === 15069) {
          setAlt({
            showAlert: true,
            title: "ATTENZIONE",
            message: "L'etichetta fornita non esiste per questo negozio!",
          });
        } else if (response.code === 13026) {
          setAlt({
            showAlert: true,
            title: "ATTENZIONE",
            message: "Dispositivi già connessi",
          });
        } else {
          setAlt({
            showAlert: true,
            title: "ATTENZIONE",
            message:
              "Errore nell'associazione degli oggetti,controlla che gli oggetti inseriti siano corretti o che siano disponibili nel catalogo.",
          });
        }
      } catch (err) {
        console.error(err);

        setAlt({
          showAlert: true,
          title: "ATTENZIONE",
          message: "Errore nell'associazione degli oggetti,",
        });
      }
    } else {
      setAlt({
        showAlert: true,
        title: "ERRORE",
        message: "Inserisci prima i codici di prodotto e etichetta",
      });
    }

    setLoading(false);
  }

  useEffect(() => {
    if (tabacchiCode1.length - prevCode1?.length > 5) {
      setTimeout(() => barcode2Ref.current.focus(), 500);
    }
  }, [tabacchiCode1]);

  useEffect(() => {
    if (tabacchiCode2.length - prevCode2?.length > 5) {
      setTimeout(() => eslRef.current.focus(), 500);
    }
  }, [tabacchiCode2]);

  useEffect(() => {
    if (eslCode.length - prevEsl?.length > 5) bind();
  }, [eslCode]);

  return (
    <View style={styles.main}>
      <View style={styles.inputContainer}>
        <InputCode
          id={1}
          value={tabacchiCode1}
          setValue={setTabacchiCode1}
          label="Barcode Prodotto 1"
          withNFC={false}
          ref={barcode1Ref}
        />

        <InputCode
          id={2}
          value={tabacchiCode2}
          setValue={setTabacchiCode2}
          label="Barcode Prodotto 2"
          withNFC={false}
          ref={barcode2Ref}
        />

        <InputCode
          id={3}
          value={eslCode}
          setValue={setESLCode}
          label="Codice ESL"
          ref={eslRef}
        />
      </View>

      <View style={styles.tableContainer}>
        <View style={styles.tableInner}>
          <View style={{ width: "90%" }}>
            <AwesomeButton
              backgroundDarker="#e8e8e8"
              width="100%"
              type="primary"
              backgroundColor={colore}
              borderRadius={6}
              height={60}
              raiseLevel={5}
              progress
              onPress={(next) => {
                bind();
                next();
              }}
            >
              {loading ? (
                <Progress.Circle
                  size={30}
                  borderWidth={5}
                  indeterminate={true}
                  color="white"
                />
              ) : (
                <Text
                  style={{ fontSize: 18, fontWeight: "bold", color: "white" }}
                >
                  ASSOCIA
                </Text>
              )}
            </AwesomeButton>
          </View>
        </View>
      </View>

      <View style={styles.alert}>
        <AwesomeAlert
          overlayStyle={{ height: "100%" }}
          titleStyle={{ color: "red", fontWeight: "bold" }}
          messageStyle={{ textAlign: "center" }}
          contentContainerStyle={{ borderColor: colore, borderWidth: 2 }}
          show={Alt.showAlert}
          showProgress={Alt.showAlert}
          title={Alt.title}
          message={Alt.message}
          closeOnTouchOutside={true}
          closeOnHardwareBackPress={false}
          showConfirmButton={true}
          confirmText="OK"
          confirmButtonColor={colore}
          onConfirmPressed={() => setAlt({ ...Alt, showAlert: false })}
          onDismiss={() => setAlt({ ...Alt, showAlert: false })}
          showProgress={true}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  main: {
    backgroundColor: "white",
    width: "100%",
    height: "100%",
  },
  tableContainer: {
    marginVertical: 40,
    flex: 1,
    minHeight: 400,
  },
  tableInner: {
    alignItems: "center",
  },
  alert: {},
  spinnerTextStyle: {
    color: "#FFF",
  },
  inputContainer: {
    marginTop: "10%",
    flexDirection: "column",
    height: "25%",
    justifyContent: "space-between",
    paddingHorizontal: 10,
  },
});

TouchableOpacity.defaultProps = { activeOpacity: 0.5 };
export default MulticomodityBinding;
