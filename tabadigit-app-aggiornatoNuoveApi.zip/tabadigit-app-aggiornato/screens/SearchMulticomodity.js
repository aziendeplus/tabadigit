import React, { useEffect } from "react";
import { StyleSheet, View, FlatList, ActivityIndicator } from "react-native";
import { colore } from "../colore";
import {
  apiWithRetry,
  getMulticomodityTemplates,
} from "../api";
import { useDispatch, useSelector } from "react-redux";
import TemplateCard from "../components/TemplateCard";

const SearchMulticomodity = () => {
  const dispatch = useDispatch();
  const { token, selectedStore } = useSelector((rootState) => rootState.auth);
  const [templates, setTemplates] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [loading, setLoading] = React.useState(true);
  const [searchText, setSearchText] = React.useState("");

  const handleEndReached = React.useCallback(() => {
    setPage((page) => page + 1);
    getTemplates();
  }, []);

  async function getTemplates() {
    setLoading(true);

    try {
      const newTemplates = await apiWithRetry(
        () => getMulticomodityTemplates(token, page, selectedStore, searchText),
        dispatch
      );

      let arr = newTemplates.data?.content || [];

      if (page === 0) {
        setTemplates(arr);
      } else {
        setTemplates([...templates, ...arr]);
      }
    } catch (error) {
      console.error(error);
    }
    setLoading(false);
  }

  const initializeSearch = () => {
    setPage(0);
    getTemplates();
  };

  useEffect(() => {
    getTemplates();
  }, []);

  return (
    <View style={styles.main}>
      {loading && (
        <View style={styles.loading}>
          <ActivityIndicator color={colore} animating={loading} size="large" />
        </View>
      )}

      <FlatList
        refreshing={loading}
        style={styles.list}
        data={templates}
        progressViewOffset={10}
        onEndReachedThreshold={0.01}
        onEndReached={handleEndReached}
        renderItem={({ item }) => (
          <View style={styles.content}>
            <TemplateCard template={item} />
          </View>
        )}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  main: {
    width: "100%",
    flexDirection: "column",
    flex: 1,
    backgroundColor: "white",
  },
  filterContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    width: "100%",
    paddingHorizontal: 10,
    marginTop: 10,
    minHeight: 100,
  },
  textFilter: {
    flex: 0.9,
  },
  list: {
    flex: 1,
  },
  loading: {
    position: "absolute",
    width: "100%",
    height: "100%",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#f4f4f4",
  },
});
export default SearchMulticomodity;
