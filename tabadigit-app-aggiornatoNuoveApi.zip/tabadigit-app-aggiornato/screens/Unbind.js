import React, { useCallback, useState, useRef, useEffect } from "react";
import { StyleSheet, View, Text } from "react-native";
import AwesomeAlert from "react-native-awesome-alerts";
import AwesomeButton from "react-native-really-awesome-button";
import { apiWithRetry, unbindItem } from "../api";
import { colore } from "../colore";
import InputCode from "../components/InputCode";
import { useDispatch, useSelector } from "react-redux";
import * as Progress from "react-native-progress";
import { usePrevious } from "../utils";

const Dettagli = ({}) => {
  const { token, selectedStore } = useSelector((rootState) => rootState.auth);
  const [eslCode, setESLCode] = useState("");
  const [loading, setLoading] = useState(false);
  const eslRef = useRef();
  const dispatch = useDispatch();
  const prevEsl = usePrevious(eslCode);

  const [Alt, setAlt] = React.useState({
    showAlert: false,
    title: "",
    message: "",
  });

  useEffect(() => {
    if (eslRef?.current) eslRef.current.focus();
  }, [eslRef]);

  const onPress = useCallback(async () => {
    setLoading(true);
    try {
      const response = await apiWithRetry(
        () => unbindItem(token, selectedStore, eslCode),
        dispatch
      );
      console.log(response);
      if (response.success) {
        setAlt({
          showAlert: true,
          title: "Scollegato",
          message: "Prodotto scollegato",
        });
      } else {
        setAlt({
          showAlert: true,
          title: "ERRORE",
          message: "Si è presentato un problema durante la richiesta",
        });
      }
    } catch (err) {
      console.error(err);

      setAlt({
        showAlert: true,
        title: "ERRORE",
        message: "Si è presentato un problema durante la richiesta",
      });
    } finally {
      setLoading(false);
    }
  }, [eslCode, token, selectedStore]);

  useEffect(() => {
    if (eslCode.length - prevEsl?.length > 5) onPress();
  }, [eslCode]);

  return (
    <View style={styles.main}>
      <AwesomeAlert
        titleStyle={{ color: "red", fontWeight: "bold" }}
        messageStyle={{ textAlign: "center" }}
        contentContainerStyle={{ borderColor: colore, borderWidth: 2 }}
        overlayStyle={{ height: "100%" }}
        show={Alt.showAlert}
        showProgress={Alt.showAlert}
        title={Alt.title}
        message={Alt.message}
        closeOnTouchOutside={true}
        closeOnHardwareBackPress={false}
        showConfirmButton={true}
        confirmText="OK"
        confirmButtonColor={colore}
        onConfirmPressed={() => setAlt({ ...Alt, showAlert: false })}
        onDismiss={() => setAlt({ ...Alt, showAlert: false })}
        showProgress={true}
      />

      <View style={styles.input}>
        <InputCode
          ref={eslRef}
          id={13}
          value={eslCode}
          setValue={setESLCode}
          label="Codice ESL"
        />

        <View style={styles.button}>
          <AwesomeButton
            backgroundDarker="#e8e8e8"
            width="100%"
            type="primary"
            backgroundColor={colore}
            borderRadius={6}
            height={60}
            raiseLevel={4}
            onPress={(next) => {
              onPress();
              next();
            }}
            disabled={!eslCode}
          >
            {loading ? (
              <Progress.Circle
                size={30}
                borderWidth={5}
                indeterminate={true}
                color="white"
              />
            ) : (
              <Text style={styles.buttonText}>Scollega</Text>
            )}
          </AwesomeButton>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  main: {
    flex: 1,
    alignContent: "center",
    justifyContent: "center",
    paddingHorizontal: 15,
    backgroundColor: "white",
  },
  button: {
    marginTop: 20,
    maxWidth: 500,
    alignItems: "center",
    justifyContent: "center",
  },
  input: {
    flex: 1,
    alignContent: "center",
    justifyContent: "center",
  },
  buttonText: { fontSize: 19, fontWeight: "bold", color: "white" },
  details: {
    flex: 3,
  },
});

export default Dettagli;
