import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import TextInputDetail from "../components/TextInputDetail";
import AwesomeButton from "react-native-really-awesome-button";
import { colore } from "../colore";
import { getCategories, createItem, getTemplates, apiWithRetry } from "../api";
import AwesomeAlert from "react-native-awesome-alerts";
import InputCode from "../components/InputCode";
import { useDispatch, useSelector } from "react-redux";

const DettagliProdotto = () => {
  const { token } = useSelector((rootState) => rootState.auth);

  const [categories, setCategories] = useState();
  const [templates, setTemplates] = useState();
  const [alert, setAlert] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState();
  const [selectedTemplate, setSelectedTemplate] = useState();
  const [selectedPrice, setSelectedPrice] = useState("");
  const [selectedProductAms, setProductAms] = useState("");
  const [selectedName, setName] = useState("");
  const [barCode, setBarcode] = useState("");
  const [type, setType] = useState("");
  const [priceKg, setPriceKg] = useState("");
  const [unitaminima, setUnitaMinima] = useState("");
  const [pack, setPackage] = useState("");
  const [nOnPack, setNonPack] = useState("");
  const dispatch = useDispatch();

  useEffect(() => {
    async function fetch() {
      try {
        const categoriesResponse = await apiWithRetry(
          () => getCategories(token),
          dispatch
        );

        setCategories(categoriesResponse.data);
        setSelectedCategory(categoriesResponse.data[0]);

        const templatesResponse = await apiWithRetry(
          () => getTemplates(token),
          dispatch
        );
        setTemplates(templatesResponse.data);
        setSelectedTemplate(
          templatesResponse.data.find(
            (t) => t.categoryName == categoriesResponse.data[0].categoryName
          )
        );
      } catch (error) {
        console.error(error);
        setAlert(true);
      }
    }

    fetch();
  }, []);

  const setTemplate = (value) => {
    setSelectedTemplate(templates.find((t) => t.attrName === value));
  };

  function setCategory(value) {
    setSelectedCategory(categories.find((c) => c.categoryName === value));
    setSelectedTemplate(templates.find((t) => t.categoryName === value));
  }

  async function onSubmit() {
    try {
      await apiWithRetry(
        () =>
          createItem(token, {
            ...getEmptyItemFields(),
            custFeature1: type,
            custFeature2: priceKg,
            custFeature3: unitaminima,
            custFeature4: pack,
            custFeature5: nOnPack,
            itemTitle: selectedName,
            barCode,
            productCode: selectedProductAms,
            price: selectedPrice,
            attrCategory: selectedCategory?.categoryName,
            attrName: selectedTemplate?.attrName,
          }),
        dispatch
      );
    } catch (error) {
      console.error(error);
      setAlert(true);
    }
  }

  let templatesOption = null;

  if (selectedCategory && selectedTemplate) {
    const categoryToFilter = selectedCategory?.categoryName;

    templatesOption = templates
      ?.filter((t) => t.categoryName === categoryToFilter)
      ?.map((t) => t.attrName);
  }

  const onChangePrice = (value) => {
    setSelectedPrice(value.replace(",", ".").replace(/[^\d.]/, ""));
  };

  const onChangePackagePrice = (value) => {
    setPriceKg(value.replace(",", ".").replace(/[^\d.]/, ""));
  };

  const onChangeUnitaMinima = (value) => {
    setUnitaMinima(value.replace(",", ".").replace(/[^\d.]/, ""));
  };

  return (
    <View style={styles.main}>
      <AwesomeAlert
        overlayStyle={{ height: "100%" }}
        show={alert}
        showProgress={alert}
        title="ERRORE"
        message="Errore durante la lettura del prodotto"
        closeOnTouchOutside={true}
        closeOnHardwareBackPress={false}
        showConfirmButton={true}
        confirmText="OK"
        confirmButtonColor={colore}
        onConfirmPressed={() => setAlert(false)}
        onDismiss={() => setAlert(false)}
      />
      <ScrollView style={{ width: "100%" }}>
        <TextInputDetail
          title="Codice AMS"
          value={selectedProductAms}
          editable={true}
          onChange={setProductAms}
        />
        <TextInputDetail
          title="Nome"
          value={selectedName}
          editable={true}
          onChange={setName}
        />
        <TextInputDetail
          title="Prezzo"
          value={selectedPrice?.toString()}
          editable={true}
          onChange={onChangePrice}
          numberPad
        />

        <View style={styles.barcode}>
          <Text style={styles.textBarCode}>Barcode</Text>
          <InputCode id={13} value={barCode} setValue={setBarcode} label="" />
        </View>
        <TextInputDetail
          title="Tipologia"
          value={type}
          editable={true}
          onChange={setType}
        />
        {categories && (
          <TextInputDetail
            title="Categoria template"
            value={selectedCategory?.categoryName}
            editable={true}
            onChange={setCategory}
            transform={true}
            labels={categories?.map((c) => c.categoryName)}
          />
        )}
        {templatesOption && (
          <TextInputDetail
            title="Template"
            value={selectedTemplate?.attrName}
            editable={true}
            onChange={setTemplate}
            transform={true}
            labels={templatesOption}
          />
        )}
        <TextInputDetail
          title="Unità"
          onChange={setNonPack}
          value={nOnPack}
          editable={true}
        />
        <TextInputDetail
          title="Prezzo al Kg"
          value={priceKg}
          editable={true}
          onChange={onChangePackagePrice}
          numberPad
        />
        <TextInputDetail
          title="UnitaMinima"
          value={unitaminima}
          editable={true}
          onChange={onChangeUnitaMinima}
          numberPad
        />
        <TextInputDetail
          title="Tipo pacchetto"
          value={pack}
          editable={true}
          onChange={setPackage}
        />
      </ScrollView>
      <View style={{ width: "100%", marginVertical: 20, alignItems: "center" }}>
        <View style={{ width: "60%" }}>
          <AwesomeButton
            backgroundDarker="#e8e8e8"
            width="100%"
            type="primary"
            backgroundColor={colore}
            borderRadius={6}
            height={60}
            raiseLevel={5}
            progress={true}
            onPress={(next) => {
              onSubmit();
              next();
            }}
          >
            <Text style={styles.buttonText}>Crea</Text>
          </AwesomeButton>
        </View>
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  main: {
    width: "100%",
    height: "100%",
    backgroundColor: "white",
  },
  buttonText: { fontSize: 20, fontWeight: "bold", color: "white" },
  textBarCode: {
    fontSize: 17,
    fontWeight: "bold",
    color: colore,
  },
  barcode: {
    marginTop: 20,
    marginLeft: 10,
    flexDirection: "row",
    alignContent: "center",
    alignItems: "center",
  },
});

export function getEmptyItemFields() {
  return {
    agencyId: "",
    brandName: "",
    classLevel: "",
    contentList: [],
    createdTime: "",
    custFeature2: "",
    custFeature3: "",
    custFeature4: "",
    custFeature5: "",
    custFeature6: "",
    custFeature7: "",
    custFeature8: "",
    custFeature9: "",
    custFeature10: "",
    custFeature11: "",
    custFeature12: "",
    custFeature13: "",
    delPicIds: [],
    delTime: "",
    isSpecs: "0",
    itemPictureList: [],
    itemSkuList: [],
    itemSpecsGroupBeanList: [{ type: "", contentList: [] }],
    itemSpecsSkuVoList: [],
    memberPrice: "",
    nfcUrl: "",
    number: 0,
    originalPrice: "",
    proEndTime: null,
    proStartTime: null,
    productArea: "",
    productSku: "",
    promotionText: "",
    qrCode: "",
    shelfNum: "",
    shortTitle: "",
    sourceCode: "",
    spec: "",
    stock1: "",
    stock2: "",
    stock3: "",
    storeId: "",
    type: 0,
    unit: "",
  };
}

export default DettagliProdotto;
