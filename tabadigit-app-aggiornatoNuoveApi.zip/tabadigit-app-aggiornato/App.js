/**
 * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe
 * www.tabadigit.it
 * Tutti i diritti riservati.
 */

import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import SignIn from "./screens/SignIn";
import { useEffect } from "react";
import QRpage from "./screens/QRpage";
import Main from "./screens/Main";
import Collega from "./screens/CardScreens/Collega";
import Dettagli from "./screens/Dettagli";
import Invert from "./screens/Invert";
import Unbind from "./screens/Unbind";
import Home from "./screens/Home";
import MulticomodityBinding from "./screens/MulticomodityBinding";
import { deleteCredentials } from "./secureStore";
import Prodotti from "./screens/CardScreens/Prodotti";
import DettagliProdotto from "./screens/DettagliProdotto";
import CreaProdotto from "./screens/CreaProdotto";
import SearchMulticomodity from "./screens/SearchMulticomodity";
import { colore } from "./colore";
import { StatusBar, LogBox } from "react-native";
import PlusButton from "./components/PlusButton";
import { useDispatch, useSelector } from "react-redux";
import { SIGN_OUT, ERROR } from "./store/authReducer";
import { signIn } from "./store/authActions";
import DuplicaProdotto from "./screens/DuplicaProdotto";
import ErrorBoundary from "./utils/ErrorBoundary";

// Ignora avvisi non critici per migliorare la stabilità
LogBox.ignoreLogs(['Warning: ...']); // Ignora avvisi specifici
LogBox.ignoreAllLogs(); // Ignora tutti gli avvisi (usare con cautela)

export const Stack = createStackNavigator();

const headerOptions = {
  headerStyle: {
    backgroundColor: colore,
  },
  headerTitleAlign: "center",
  headerTitleStyle: {
    fontWeight: "bold",
    fontSize: 24,
    color: "white",
    textAlign: "center",
  },
  headerTintColor: "white",
};

export default function App() {
  const state = useSelector((rootState) => rootState.auth);

  const dispatch = useDispatch();

  useEffect(() => {
    console.log("SIGNIN");
    dispatch(signIn());
  }, []);

  return (
    <ErrorBoundary>
      <StatusBar translucent={true} backgroundColor={colore} />
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen
            name="SignIn"
            component={SignIn}
            error={state.error}
            options={{
              title: "Accedi",
              headerShown: false,
              // When logging out, a pop animation feels intuitive
              animationTypeForReplace: state.isSignout ? "pop" : "push",
            }}
          />

          <Stack.Screen
            name="Main"
            component={Main}
            options={{
              headerShown: false,
            }}
          />
          <Stack.Screen
            name="Collega"
            component={Collega}
            options={{
              title: "Collega",
              ...headerOptions,
            }}
          />
          <Stack.Screen
            name="QRpage"
            component={QRpage}
            options={{
              headerShown: false,
            }}
          />
          <Stack.Screen
            name="Dettagli"
            component={Dettagli}
            options={{
              title: "Dettagli Etichetta",
              ...headerOptions,
            }}
          />
          <Stack.Screen
            name="Unbind"
            component={Unbind}
            options={{
              title: "Scollega",
              ...headerOptions,
            }}
          />
          <Stack.Screen
            name="Invert"
            component={Invert}
            options={{
              title: "Inverti",
              ...headerOptions,
            }}
          />
          <Stack.Screen
            name="Prodotti"
            component={Prodotti}
            options={{
              title: "Prodotti",
              ...headerOptions,
              headerRight: state.canAddGoods ? () => <PlusButton /> : null,
            }}
          />

          <Stack.Screen
            name="SearchMulticomodity"
            component={SearchMulticomodity}
            options={{
              title: "Ricerca Template",
              ...headerOptions,
            }}
          />

          <Stack.Screen
            name="MulticomodityBinding"
            component={MulticomodityBinding}
            options={{
              title: "Collega dispositivi",
              ...headerOptions,
            }}
          />

          <Stack.Screen
            name="DettagliProdotto"
            component={DettagliProdotto}
            options={{
              title: "Dettagli Prodotto",
              ...headerOptions,
            }}
          />

          <Stack.Screen
            name="CreaProdotto"
            component={CreaProdotto}
            options={{
              title: "Crea Prodotto",
              ...headerOptions,
            }}
          />

          <Stack.Screen
            name="DuplicaProdotto"
            component={DuplicaProdotto}
            options={{
              title: "Duplica Prodotto",
              ...headerOptions,
            }}
          />
          <Stack.Screen
            name="Home"
            component={Home}
            options={{
              title: "Ordine",
              ...headerOptions,
            }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </ErrorBoundary>
  );
}
