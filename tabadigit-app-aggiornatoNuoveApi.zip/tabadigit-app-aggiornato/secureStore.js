
import * as SecureStore from "expo-secure-store";

const KEYSTORE_KEY = "passwordUsername";
export async function saveCredentials(username, password) {
    await SecureStore.setItemAsync(KEYSTORE_KEY, JSON.stringify({username, password}));
}
  
export async function getCredentials() {
    let result = await SecureStore.getItemAsync(KEYSTORE_KEY);
    return JSON.parse(result);
}

export async function deleteCredentials() {
    await SecureStore.deleteItemAsync(KEYSTORE_KEY);
}