/* * Copyright (c) 2023-2025 M.G.Informatica di Mandalà Giuseppe * www.tabadigit.it *
Tutti i diritti riservati. */

export const SERVER_IP = "http://195.231.7.184";
export const SERVER = "http://195.231.7.184";
export const SERVER_FT = "http://195.231.7.184";
export const API_PATH = "/zk";
