export const SIGN_IN = "SIGN_IN";
export const RESTORE_TOKEN = "RESTORE_TOKEN";
export const SIGN_OUT = "SIGN_OUT";
export const ERROR = "ERROR";
export const LOADING = "LOADING";
export const SET_STORES = "SET_STORES";
export const SELECT_STORE = "SELECT_STORE";
export const SET_STORE_INFO = "SET_STORE_INFO";
export const RESIGN = "RESIGN";

const initialState = {
  isSignout: false,
  token: null,
  error: null,
  stores: null,
  selectedStore: null,
  storesInfo: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    case SELECT_STORE:
      return {
        ...state,
        selectedStore: action.payload,
      };
    case SET_STORES:
      return {
        ...state,
        stores: action.payload,
      };
    case LOADING:
      return {
        ...state,
        loading: true,
      };
    case RESTORE_TOKEN:
      return {
        ...state,
        token: action.token,
        loading: false,
      };
    case RESIGN:
      return {
        ...state,
        token: action.payload.token,
        loading: false,
      };
    case SIGN_IN:
      return {
        ...state,
        isSignout: false,
        token: action.payload.token,
        canAddGoods: action.payload.canAddGoods,
        loading: false,
      };
    case SIGN_OUT:
      return {
        ...state,
        isSignout: true,
        token: null,
        loading: false,
        stores: null,
        selectedStore: null,
      };
    case ERROR:
      return {
        ...state,
        isSignout: true,
        token: null,
        error: action.payload,
        loading: false,
        stores: null,
        selectedStore: null,
      };
    case SET_STORE_INFO:
      let newStoresInfo = {};

      if (state.storesInfo) newStoresInfo = { ...state.storesInfo };

      newStoresInfo[action.payload.storeId] = action.payload.eslCodes;
      return {
        ...state,
        storesInfo: newStoresInfo,
      };
    default:
      return state;
  }
};
