import {
  getPublicKey,
  login,
  getStores,
  loadingStoreInfo,
  getUser,
  logout,
} from "../api";
import JSEncrypt from "jsencrypt";
import {
  SIGN_IN,
  RESTORE_TOKEN,
  SIGN_OUT,
  ERROR,
  LOADING,
  SET_STORES,
  SELECT_STORE,
  SET_STORE_INFO,
  RESIGN,
} from "./authReducer";

import { saveCredentials, getCredentials } from "../secureStore";

export const selectStore = (storeId) => {
  return (dispatch, getState) => {
    try {
      const state = getState();
      dispatch({ type: SELECT_STORE, payload: storeId });
      if (state.auth.storesInfo && state.auth.storesInfo[storeId]) return;

      loadingStoreInfo(state.auth.token, storeId).then((eslCodes) => {
        dispatch({ type: SET_STORE_INFO, payload: { storeId, eslCodes } });
      });
    } catch (error) {
      console.log(error);
    }
  };
};

export const flushError = () => {
  return (dispatch) => {
    dispatch({ type: ERROR, payload: null });
  };
};

export const signOut = () => {
  return async (dispatch) => {
    const { username } = await getCredentials();
    const response = await logout(username);
    console.log("LOGOUT", response);
    dispatch({ type: SIGN_OUT });
  };
};

export const encryptPassword = async (password) => {
  const publicKeyResponse = await getPublicKey();

  const base64PubKey = publicKeyResponse.data;

  var encrypt = new JSEncrypt();

  encrypt.setPublicKey(base64PubKey);
  return encrypt.encrypt(password);
};

export const signIn = (data = {}) => {
  return async (dispatch, getState) => {
    const state = getState();

    dispatch({ type: LOADING });
    try {
      let { username, password } = data;

      if (!username || !password) {
        const credentials = await getCredentials();

        if (credentials) {
          username = credentials.username;
          password = credentials.password;
        } else {
          return console.log("No credentials");
        }
      }

      if (state.auth.token) await dispatch(signOut());

      var encryptedPassword = await encryptPassword(password);

      const loginResponse = await login(username, encryptedPassword);

      console.log("Login Okay");
      if (!loginResponse?.data?.token) {
        return dispatch({ type: ERROR, payload: "Credenziali Errate" });
      }

      const token = loginResponse.data.token;

      console.log(token);
      const userInfo = await getUser(token, loginResponse.data.currentUser.id);

      const canAddGoods = userInfo.data.menuLists.some(
        (m) => m.menuName === "goodquery"
      );

      saveCredentials(username, password);

      dispatch({ type: SIGN_IN, payload: { token, canAddGoods } });

      console.log("STORES", state.auth.stores);
      if (!state.auth.stores) {
        const stores = await getStores(token);
        dispatch({ type: SET_STORES, payload: stores });
        if (!state.auth.selectedStore) dispatch(selectStore(stores[0].storeId));
      }
    } catch (err) {
      console.log(err);
      dispatch({
        type: ERROR,
        payload: "Problemi di rete. Riprovare più tardi",
      });
    }
  };
};
